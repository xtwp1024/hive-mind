"""
PWP-QA: Parallel Worlds Paradigm for Code QA
平行世界范式代码质量保证框架

┌──────────────────────────────────────────────────────────────┐
│  概念定义                                                     │
│  PWP-QA 是一种"分布采样驱动"的代码 QA 方法:                    │
│  对同一 prompt 进行 N 次独立采样得到 N 份代码 (平行宇宙),        │
│  通过分析它们的差异分布来定位 bug 候选并衡量 prompt 质量.       │
│                                                              │
│  解决的问题:                                                  │
│    传统 code review 只能审"那一版"代码, 无法区分              │
│    "LLM 偶然写对"与"prompt 真正约束住了行为".                  │
│    PWP-QA 用"多宇宙共识"替代"单版本信任".                     │
└──────────────────────────────────────────────────────────────┘

核心思想 (三条铁律):
  1. 不审"那一版" -> 审"所有宇宙的公约数"   (共识才可信)
  2. 孤岛先于公约数 -> 异常比正确更重要        (差异暴露 bug)
  3. UCS < 阈值时停审 -> 分布未收敛, 回头改 prompt (先收敛再审查)
     阈值由经验校准确定 (默认 0.6, 52-prompt 实证校准后为 0.5),
     由 load_thresholds() 从 thresholds.json 加载, 可替换.

方法论流水线 (L1→L7, 核心层):
  L1 宇宙生成  -> 同 prompt N 次采样
  L2 宇宙对齐  -> 字面 / 行 / AST 函数级
  L2.5 IO 等价 -> 区分"风格差异"与"真 bug"
  L3 差异三分  -> 公约数 / 分叉 / 孤岛
  L4 QA 信号   -> 强(必查正确性) / 中(验证等价) / 弱(强制 review)
  L5 度量      -> UCS / 鲁棒性 / 收敛度
  L6 反向优化  -> UCS<阈值时给出 prompt 改进建议
  L7 闭环收敛  -> 自动改 prompt + 重跑, 直到 UCS≥阈值;
                  或不变量门达标 (invariant_satisfied):
                  ambiguous 场景改写无法提升 UCS 时的第二验收通道 (P0-3 修复)

工程支撑层 (非方法论核心, 不计入流水线编号):
  L0   成本缓存   -> sha256(model+prompt+seed) 跳过重复 API 调用
  L0*  趋势追踪   -> trend.jsonl 记录历史 UCS, 观察长期收敛趋势

用法:
  from pwp_qa import run
  report = run(prompt, generator, n=5, level="ast")
  print(report.to_markdown())
"""

from __future__ import annotations

import difflib
import hashlib
import json
import math
import os
import random
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, List, Optional, Tuple

# tree-sitter 可选导入 (AST 对齐模式需要)
try:
    import tree_sitter_python as _tspython
    from tree_sitter import Parser as _TSParser, Language as _TSLanguage
    _TS_AVAILABLE = True
    _PY_LANG = _TSLanguage(_tspython.language())
    _PARSER = _TSParser(_PY_LANG)
except ImportError:
    _TS_AVAILABLE = False
    _PY_LANG = None
    _PARSER = None

# LLM 客户端可选导入 (真实 LLM 集成需要)
try:
    import openai as _openai
    _OPENAI_AVAILABLE = True
except ImportError:
    _openai = None
    _OPENAI_AVAILABLE = False

try:
    import anthropic as _anthropic
    _ANTHROPIC_AVAILABLE = True
except ImportError:
    _anthropic = None
    _ANTHROPIC_AVAILABLE = False

try:
    import httpx as _httpx
    _HTTPX_AVAILABLE = True
except ImportError:
    _httpx = None
    _HTTPX_AVAILABLE = False

__version__ = "0.2.3"


# ══════════════════════════════════════════════════════════════
# 概念声明 (Conceptual Declaration)
# ══════════════════════════════════════════════════════════════
#
# 1. 核心假设与边界
# ──────────────────────────────────────────────────────────────
# PWP-QA 建立在以下假设之上, 任一假设被打破时结论可能失真:
#
#   A1. 采样独立: N 次调用必须使用不同 seed 且互相独立;
#                若 LLM 有状态/cache 导致宇宙高度相关, UCS 会虚高.
#   A2. 差异反映 prompt 质量: 同 prompt 的差异分布主要由 prompt
#                约束不足引起, 而非 LLM 能力退化; 若模型本身不稳定,
#                孤岛增多是模型问题而非 prompt 问题.
#   A3. 公约数 = 可信骨架: 出现在所有宇宙的代码大概率是"必须的",
#                但不保证绝对正确 (全宇宙可能犯同一个错).
#   A4. 孤岛 = bug 候选: 只出现在个别宇宙的代码是"异常", 但可能是
#                合理的可选实现 (需 L2.5 IO 等价进一步区分).
#
# 边界条件:
#   - 适用于"有明确输入输出"的函数/模块; 不适用于纯 UI/布局/艺术生成.
#   - 适用于"可独立执行"的代码片段; 不适用于强依赖外部状态的场景.
#   - N 推荐 3~10; N<3 统计意义不足, N>10 成本收益递减.
#
# 2. 术语表
# ──────────────────────────────────────────────────────────────
#   Universe (宇宙):       一次 LLM 生成的完整代码.
#   Consensus (公约数):    出现在所有宇宙的代码/函数 (必然骨架).
#   Branching (分叉):      出现在部分宇宙且有多变体的代码 (实现选项).
#   Outlier (孤岛):        只出现在个别宇宙的代码 (异常, bug 候选).
#   UCS (Universe Convergence Score): 公约数占比, 衡量分布收敛度.
#   Robustness (鲁棒性):    1 - 孤岛率, 衡量"不出现异常"的稳定度.
#   Convergence (收敛度):   1 - 分叉率, 衡量"实现一致"的程度.
#   Triage (三分):          把差异分为 公约数 / 分叉 / 孤岛 的过程.
#   IO Equivalence (IO 等价): 多个变跑同一组测试全过 => 行为等价.
#
# 3. 适用场景
# ──────────────────────────────────────────────────────────────
#   ✓ LLM 生成代码的 QA (code review 前置筛选)
#   ✓ Prompt 工程质量评估 (同一 prompt 反复跑看 UCS 趋势)
#   ✓ 教学/示例代码的稳健性验证
#   ✓ 多模型对比 (同一 prompt 不同模型的 UCS 差异)
#
# 4. 不适用场景
# ──────────────────────────────────────────────────────────────
#   ✗ 已有完善单元测试覆盖的成熟模块 (直接跑测试更高效)
#   ✗ 一次性脚本 / 强类型编译期已保证正确性的代码
#   ✗ 需要多步交互/状态机的复杂逻辑 (单函数 IO 测试不够)
#   ✗ 对延迟极度敏感的场景 (N 次采样成本高)
#
# 5. 与其他 QA 方法的关系
# ──────────────────────────────────────────────────────────────
#   - vs 单元测试: PWP-QA 不替代单测, 而是"发现该测什么"
#     (孤岛/分叉告诉 reviewer 哪里需要补测试).
#   - vs Mutation Testing: 变异测试人工注入故障; PWP-QA 用
#     LLM 自然采样的差异作为"天然变异", 成本更低但可控性差.
#   - vs Property-Based Testing: PBT 验证性质; PWP-QA 先定位
#     高风险函数, 再建议对其做 PBT (互补).
#   - vs Fuzzing: Fuzzing 找崩溃; PWP-QA 找"语义分歧" (不同
#     实现对同输入输出不同).
#   - vs Code Review: PWP-QA 是 review 的"预筛层", 把 reviewer
#     注意力引向孤岛/分叉, 减少盲审.
#
# 6. 失败模式 (PWP-QA 本身可能失效的情况)
# ──────────────────────────────────────────────────────────────
#   F1. 模型退化: 所有宇宙输出几乎相同 (UCS≈1 但代码有 bug) ->
#       公约数可能是错的; 需结合单测验证.
#   F2. Prompt 过宽: 分叉过多导致 UCS 极低, 但这是"功能选择空间
#       大"而非"bug" -> 需判断分叉是"风格"还是"语义".
#   F3. 测试套件不足: L2.5 IO 等价误判 (真 bug 因测试没覆盖而被判
#       等价) -> 测试覆盖率影响结论可信度.
#   F4. seed 相关: 某些 seed 触发 LLM 安全策略导致输出截断 ->
#       孤岛是"被截断"而非"实现异常".
#
# 7. 度量阈值说明 (经验校准后)
# ──────────────────────────────────────────────────────────────
#   UCS >= 阈值 为"收敛" (铁律 3). 阈值来源:
#
#   v0 (硬编码): 0.6. 依据是经验判断: 60% 共识时 review 负担可控.
#
#   v1 (经验校准, 2026-10-12, gpt-6.1-sol, 52 prompt, n=5):
#     用 ROC + Youden's J 对 52 个分级 prompt (Q1-Q5) 拟合:
#       - AUC = 0.85  (区分力良好)
#       - 拟合阈值 = 0.5  (双峰分布中点)
#       - Youden J = 0.7
#       - Cohen's d = 1.87  (大效应量)
#       - 正类(清晰)均值 UCS = 0.7, 负类(歧义)均值 = 0.0
#
#   多模型一致性:
#     gpt-6.1-sol / gpt-6-sol / gpt-5.6-sol 三模型校准阈值均为 0.5,
#     AUC 均为 0.917 (15-prompt 子集). 阈值跨模型稳定.
#
#   关键发现: UCS 是双峰分布 (0 或 1), 不是连续值.
#     - UCS=1.0 → 所有宇宙 AST 完全一致 (degenerate/unique)
#     - UCS=0.0 + 孤岛=0 + 分歧密度>1 → multi (多解, 非歧义)
#     - UCS=0.0 + 孤岛>0 → ambiguous (歧义, prompt 约束不足)
#     因此 UCS 单独的区分力有限 (AUC=0.85), 必须配合 solution_space
#     分类 (multi vs ambiguous) 才能准确判别.
#
#   加载方式: load_thresholds() 从 thresholds.json 读取,
#             无文件时回退 DEFAULT_THRESHOLDS (ucs_converged=0.6).
#             设 PWP_QA_DISABLE_CALIBRATION=1 可强制回退 0.6.
#
# 8. 操作手册 (SOP)
# ──────────────────────────────────────────────────────────────
# 拿到一个 prompt 后, 按以下步骤使用 PWP-QA:
#
#   Step 1. 选 N (宇宙数):
#     - N=3  快速冒烟 (成本低, 统计意义弱, 仅看大方向)
#     - N=5  标准 (默认, 多数场景够用)
#     - N=10 严格 (关键模块 / 上线前, 成本翻倍)
#     经验: N 每翻倍, UCS 波动收窄约 30%, 但成本线性增长.
#
#   Step 2. 跑一次 run(level="ast", test_generator=generate_test_suite):
#     report = run(prompt, generator, n=N, level="ast",
#                  test_generator=generate_test_suite)
#
#   Step 3. 看 UCS 决策 (参考第 9 节 UCS 区间决策表, 阈值=0.5):
#     - UCS < 0.3   -> prompt 严重歧义, 必须重写 (不要 review)
#     - 0.3~阈值    -> 铁律 3 触发, 用 L6 建议改 prompt 后重跑
#                     (但若 solution_space=multi, 走 IO 等价而非重写)
#     - 阈值~0.8    -> 可 review, 重点看孤岛
#     - >= 0.8      -> 高度收敛, 抽查公约数正确性即可
#
#   Step 4. 审查差异 (按优先级):
#     a. 孤岛 (outliers): 必查, 可能是 bug 或截断
#     b. 分叉且 io_equivalent=False: 真 bug 候选, 必查
#     c. 分叉且 io_equivalent=True: 风格差异, 可选 review
#     d. 公约数: 抽查 (F1 风险: 全宇宙可能犯同一个错)
#
#   Step 5. 决策:
#     - go  : UCS>=阈值 且无孤岛/无 IO 不等价分叉 -> 可合并
#     - no-go: UCS<阈值 或有孤岛/IO 不等价 -> 改 prompt 重跑或人工修
#
# 9. UCS 区间决策表 (实证修正: 阈值校准为 0.5)
# ──────────────────────────────────────────────────────────────
#   阈值 τ = load_thresholds().ucs_converged (默认 0.6, 校准后 0.5)
#
#   UCS 区间   | 解空间分类      | 含义                    | 行动
#   -----------|----------------|-------------------------|---------------------------
#   < 0.3      | ambiguous      | prompt 严重歧义         | STOP, 重写 prompt
#   < 0.3      | multi          | 问题有多解 (非歧义)     | 走 IO 等价测试, 不重写
#   0.3 ~ τ    | ambiguous      | 未收敛, prompt 有歧义   | 用 L6 建议改 prompt, 重跑
#   0.3 ~ τ    | multi          | 未收敛, 多解型           | 走 IO 等价测试区分风格 vs bug
#   τ ~ 0.8    | unique         | 收敛, 有可控分叉         | review 孤岛 + IO 不等价分叉
#   0.8 ~ 0.95 | unique         | 高度收敛                | 抽查公约数, 快速放行
#   >= 0.95    | degenerate     | 几乎完全一致            | 警惕 F1 (模型退化?), 人工验证
#
#   D:\Hive 实证 (gpt-6.1-sol, 2026-10-12):
#     - _calculate_fitness: UCS=1.0, σ=degenerate (公式明确, 完美收敛)
#     - get_top_bees:       UCS=0.0, σ=multi (top-k 实现多样, 良性多解)
#     - run_cycle:          UCS=0.0, σ: ambiguous(0.6) → multi(0.5)
#                           校准阈值把它从"误判歧义"纠正为"多解"
#     - point_mutation:     UCS=0.0, 孤岛=5, σ=ambiguous (GEP 突变逻辑复杂)
#     - evaluate:           UCS=0.0, 孤岛=3, σ=ambiguous
#
#   注: UCS 与鲁棒性/收敛度联合看 (classify_solution_space 自动判定):
#     - UCS 高 + 鲁棒性低 -> 孤岛多 (异常多), 重点查孤岛
#     - UCS 低 + 孤岛=0 + 分歧密度高 -> 多解型, 走 IO 等价 (不重写 prompt)
#     - UCS 低 + 孤岛多 -> 歧义型, prompt 既歧义又不稳定, 重写
#
# 10. 扩展度量说明
# ──────────────────────────────────────────────────────────────
# 在 UCS / 鲁棒性 / 收敛度 三个核心度量之外, 补充两个诊断维度:
#
#   - outlier_severity (孤岛严重度): 孤岛占总量的比例 (0~1).
#     与 robustness 互补: robustness 从"稳定"角度, 此字段从"危险"
#     角度直读. >0.2 意味着超过 1/5 的代码是孤岛, 需重点排查.
#
#   - divergence_density (分歧密度): 分叉函数的平均变体数.
#     =1  分叉只因"出现宇宙数不同" (某函数在部分宇宙缺失),
#          变体本身一致 -> prompt 对函数清单约束不足.
#     1~2 存在少量实现差异, 多为风格 -> 可接受.
#     >2  实现分歧激烈 -> prompt 对行为约束不足, 需补规格.
#
# 11. Prompt 质量诊断映射 (差异模式 -> prompt 问题)
# ──────────────────────────────────────────────────────────────
# 根据 triage 的差异模式, 反推 prompt 可能存在的问题:
#
#   差异模式                          | 推断的 prompt 问题
#   ----------------------------------|---------------------------
#   孤岛函数多 (outlier_severity 高)  | prompt 对"必须包含哪些函数"
#                                     | 约束不清, LLM 自行增删
#   分歧密度高 (多变体分叉)           | prompt 对"函数行为/实现"
#                                     | 约束不足, LLM 自由发挥
#   分叉且 io_equivalent=False        | prompt 有歧义, 不同解读
#                                     | 导致行为分歧 -> 需消歧
#   分叉且 io_equivalent=True         | 风格差异, prompt 无问题
#                                     | (可选统一风格)
#   UCS 极低 + 孤岛多                 | prompt 过宽, 重写
#   UCS 极高 (>=0.95) + 孤岛=0        | 警惕 F1, 也可能是 prompt
#                                     | 过窄 (牺牲灵活性)
#   函数签名分叉 (同名不同参)         | prompt 对接口签名未明确
#
# 用法: 拿到 report 后, 先看 L5 度量定位差异模式, 再查表反推
# prompt 问题, 最后用 L6 suggest_prompt_improvements 取具体建议.
#
# ══════════════════════════════════════════════════════════════
# 理论深化 (Theoretical Foundations) — 阶梯 3
# ══════════════════════════════════════════════════════════════
#
# 12. 实证命题 (A1-A4 从假设升级为经过验证的命题)
# ──────────────────────────────────────────────────────────────
# 第 1 节的 A1-A4 假设, 经过两轮实证验证:
#   第一轮 (阶梯 1, gpt-6.1-sol, 10 prompt, n=5): 概念验证
#   第二轮 (阶梯 1+, gpt-6.1-sol, 52 prompt, n=5): 统计校准
#
# ── 第一轮 (10 prompt) ──
#   命题 A1 (采样独立性):
#     证据: 10/10 prompt 两次跑 (不同 seed 组), UCS 差值=0.
#     状态: ✓ 在缓存命中 (确定性) 下成立; ⚠ 真实 LLM 采样的
#           独立性取决于模型温度 (temperature=0 时退化为确定, 不独立).
#     条件: temperature > 0 且无 cache 穿透时, A1 成立.
#
#   命题 A2 (差异反映约束而非随机性):
#     证据: 7/10 成立; 3/10 (is_palindrome, quicksort, Stack) 反例:
#           UCS=0 但 prompt 清晰, 分叉是"多个正确实现"而非约束不足.
#     修正: A2 应改为 → "差异反映解空间特性": 低 UCS 有两种原因:
#           (a) 歧义 (孤岛多) = prompt 约束不足
#           (b) 多解 (孤岛=0, 分歧密度高) = 问题本身有多解
#     状态: ⚠ 原始 A2 被实证修正; 修正后的 A2' 成立.
#
#   命题 A3 (公约数 = 可信骨架):
#     证据: 3/10 (仅解空间唯一的 prompt) 成立; 多解 prompt 无公约数.
#     状态: ✓ 在解空间唯一时成立; ✗ 在多解时不适用 (没有公约数可判).
#
#   命题 A4 (孤岛 = bug 候选):
#     证据: 10/10 成立 (歧义 prompt 孤岛数 5-106, 清晰 prompt 孤岛=0).
#     状态: ✓ 成立; 但需 L2.5 IO 等价区分"异常实现"vs"可选实现".
#
# ── 第二轮 (52 prompt, 统计校准) ──
#   阈值校准结果:
#     - 样本: 52 prompt (Q1=7, Q2=10, Q3=5, Q4=15, Q5=15), n=5
#     - 正类(Q4+Q5=30) 均值 UCS=0.7, 负类(Q1+Q2=17) 均值 UCS=0.0
#     - AUC=0.85, Youden J=0.7, Cohen's d=1.87
#     - 拟合阈值=0.5 (双峰分布中点, 非 0.6)
#   多模型对比:
#     - gpt-6.1-sol / gpt-6-sol / gpt-5.6-sol 校准阈值均=0.5, AUC 均=0.917
#     - 结论: 校准阈值跨模型稳定, 不依赖具体模型能力
#   UCS 双峰分布:
#     - 52 prompt 中 UCS 只有 0.0 或 1.0 两个值 (无中间值)
#     - 这是 LLM 采样的普遍特征 (所有 3 个模型一致)
#     - 含义: UCS 不能单独作为连续判别器, 必须配合 solution_space
#   D:\Hive 真实项目验证 (6 函数, gpt-6.1-sol, 2026-10-12):
#     - _calculate_fitness: UCS=1.0 → degenerate (公式明确, A1 验证)
#     - run_cycle: UCS=0.0, 孤岛=0 → σ: ambiguous(0.6)→multi(0.5)
#                  校准阈值纠正了误判, 验证 A2' (多解非歧义)
#     - point_mutation/evaluate: UCS=0.0, 孤岛>0 → ambiguous (prompt 需优化)
#
#   修正后的命题状态:
#     A1 ✓ (采样独立, temperature>0 时)
#     A2' ✓ (差异反映解空间特性, 非单纯 prompt 质量)
#     A3 ✓ (公约=可信骨架, 仅 unique 时适用)
#     A4 ✓ (孤岛=bug 候选, 需 IO 等价区分)
#     阈值 0.5 (经验校准, 替代硬编码 0.6)
#
# 13. UCS 的概率论基础 (形式化定义)
# ──────────────────────────────────────────────────────────────
# 设 prompt p 的解空间为 S(p), LLM 采样分布为 P(x|p, seed),
# 对 N 个宇宙 {x_1, ..., x_N}, 定义:
#
#   公约集 C = ∩_{i=1}^{N} functions(x_i)
#   分叉集 B = {f : f ∈ some x_i, f 有 ≥2 变体}
#   孤岛集 O = {f : f ∈ exactly one x_i}
#
#   UCS = |C| / (|C| + |B| + |O|)
#
# 概率解释:
#   UCS = E[1_{f ∈ C}] / E[1_{f ∈ C ∪ B ∪ O}]
#       = P(f 是共识 | f 出现在任一宇宙)
#
# 即 UCS = "随机取一个出现的函数, 它是所有宇宙共识的概率".
#
# 界限定理 (UCS 的统计可靠性):
#   设 p* = P(f ∈ C) 为真实共识概率, 用 N 次采样估计 p̂ = UCS.
#   由 Hoeffding 不等式: P(|p̂ - p*| ≥ ε) ≤ 2·exp(-2Nε²)
#
#   N=5  时: P(|p̂-p*| ≥ 0.2) ≤ 2·exp(-2·5·0.04) = 2·e^{-0.4} ≈ 1.34
#           → 界限太松 (超过 1), N=5 统计意义弱, 仅用于快速冒烟.
#   N=10 时: P(|p̂-p*| ≥ 0.15) ≤ 2·exp(-2·10·0.0225) = 2·e^{-0.45} ≈ 1.28
#           → 仍较松, 但实战中 UCS 波动已可控.
#   N=20 时: P(|p̂-p*| ≥ 0.1) ≤ 2·exp(-2·20·0.01) = 2·e^{-0.4} ≈ 1.34
#           → 需 N~50 才有严格统计保证.
#
#   实践结论: N=5 够用但非统计严格; 对关键模块用 N≥10.
#             PWP-QA 是工程工具而非统计定理, 用经验阈值补偿.
#
#   校准后的阈值统计意义 (52-prompt 实证):
#     阈值 0.5 是 ROC + Youden's J 拟合的最优分界, 不是 Hoeffding 界的产物.
#     它的可信度由 AUC=0.85 和 Bootstrap 95% CI=[0.5, 0.5] 支撑.
#     由于 UCS 是双峰分布 (0 或 1), 阈值的作用是"分类边界"而非"连续估计",
#     Hoeffding 界对 UCS 的连续性假设在双峰下不严格适用.
#     更合适的统计框架是 logistic 回归 + ROC, 而非均值估计.
#
# 14. 解空间分类定理
# ──────────────────────────────────────────────────────────────
# 定义: 解空间 S(p) = {x : x 是 prompt p 的合法实现}
# 分类:
#   |S(p)| = 1  → 唯一解 (unique)
#   |S(p)| > 1  → 多解 (multi or ambiguous)
#
# 判定定理 (解空间分类不变性):
#   设 τ = load_thresholds().ucs_converged (校准阈值, 默认 0.6, 实证 0.5)
#   设 σ = solution_space(metrics), 则:
#
#   (T1) σ = "degenerate"  ⟹ UCS ≥ 0.95 ∧ outlier_severity = 0
#        (全宇宙高度一致, 警惕 F1)
#
#   (T2) σ = "unique"      ⟹ UCS ≥ τ
#        (解空间收敛, 公约可信)
#
#   (T3) σ = "multi"       ⟹ UCS < τ ∧ outlier_severity ≈ 0
#        ∧ divergence_density > 1 ∧ convergence < 1
#        (多解: 有分叉但无孤岛, 分歧是"不同正确实现")
#
#   (T4) σ = "ambiguous"   ⟹ UCS < τ ∧ outlier_severity > 0.1
#        (歧义: 有孤岛, prompt 约束不足)
#
# 关键推论:
#   (C1) UCS 低 ∧ 孤岛=0  ⟹ 多解 (非歧义), 不应重写 prompt,
#        应走 IO 等价测试 (T3)
#   (C2) UCS 低 ∧ 孤岛多  ⟹ 歧义, 应重写 prompt (T4)
#   (C3) σ = "multi" 时, A3 (公约=可信) 不适用, 因公约集可能为空
#   (C4) σ = "degenerate" 时, A1 (独立性) 可能被违反 (全宇宙相同
#        可能因 cache 穿透或 temperature=0, 而非真独立采样)
#
# IO 等价的作用:
#   对 σ = "multi" 的分叉, IO 等价测试把 B 进一步分为:
#     B_equiv = {f ∈ B : 所有变体 IO 等价}  (风格差异, 可接受)
#     B_diverge = {f ∈ B : 存在变体 IO 不等价}  (真 bug, 需消歧)
#   这把"多解"再分为"良性多解"(B_equiv) 和"恶性多解"(B_diverge).
#
# 15. 信息论视角与 PAC 界
# ──────────────────────────────────────────────────────────────
# 熵解释:
#   定义 LLM 输出熵 H(x|p) = -Σ_x P(x|p) log P(x|p)
#   当 |S(p)|=1 (唯一解) 时 H=0, UCS→1
#   当 |S(p)|→∞ 且均匀分布时 H→∞, UCS→0
#   UCS 可视为 H 的逆指标: UCS ≈ 1 - H/H_max (粗略)
#
#   解空间分类的熵特征:
#     unique:     H ≈ 0 (所有宇宙输出相同)
#     multi:      H > 0 但分布集中 (几个正确实现各占一部分)
#     ambiguous:  H > 0 且分布分散 (LLLM 各写各的, 无主导)
#     degenerate: H = 0 (退化为单点, 警惕 F1)
#
# PAC (Probably Approximately Correct) 学习界:
#   PWP-QA 的 UCS 类似 PAC 框架的"置信度":
#   - PAC: P(|h(x)-y| ≤ ε) ≥ 1-δ  (以 1-δ 概率, 误差 ≤ ε)
#   - PWP: UCS = P(f ∈ C | f 出现) ≈ 1-δ  (共识概率)
#
#   差异: PAC 的 δ 是"采样不确定性"的界;
#         PWP 的 UCS 是"实际观察到的共识率", 不是概率界.
#   但 Hoeffding 界 (第 13 节) 可把 UCS 转为 p* 的置信界:
#     P(p* ≥ UCS - ε) ≥ 1 - 2·exp(-2Nε²)
#   即: 以高概率, 真实共识率 p* 不低于 UCS - ε.
#
#   实践含义: UCS=0.6, N=5, ε=0.2 → P(p* ≥ 0.4) ≥ 1-1.34
#           → 界限太松, 不能给出严格 PAC 保证.
#           但 UCS=0.9, N=10, ε=0.1 → P(p* ≥ 0.8) ≥ 1-0.67
#           → 仍非严格. PWP-QA 是工程启发式, 非统计定理.
#
# PWP-QA 的认识论地位:
#   PWP-QA 不是"证明代码正确"的方法 (那是形式化验证的事).
#   PWP-QA 是"利用 LLM 采样多样性作为免费变异测试"的启发式:
#   - 公约数 ≠ 正确 (全宇宙可能同错) → 不能替代单测
#   - 孤岛 = 异常 (个别宇宙跑偏) → 可以定位 bug 候选
#   - 多解 ≠ bug (问题本身有多解) → 需要 IO 等价区分
#   - 歧义 = prompt 问题 (LLM 各写各的) → 应重写而非 review
#
#   正确用法: PWP-QA 作为 code review 前的"预筛层",
#   把 reviewer 注意力引向高风险区域 (孤岛 + IO 不等价分叉),
#   而非替代形式化验证或单元测试.
#
# 16. 最优决策路径 (决策论)
# ──────────────────────────────────────────────────────────────
# 从第 14 节的解空间分类 σ 推导最优行动 (决策论视角):
#
# 决策空间 A = {release, review, rewrite_prompt, run_io_test,
#               verify_degenerate, increase_N}
# 代价函数 Cost(a, σ):
#   release: 0 (如果 σ=unique) / ∞ (如果 σ≠unique, 漏 bug 风险)
#   review:  人工成本 c_r (审查孤岛+分叉)
#   rewrite_prompt: 重写成本 c_w > c_r
#   run_io_test:    API 成本 c_io (跑测试套件)
#   verify_degenerate: 人工验证成本 c_v (验证是否 F1)
#   increase_N:     采样成本 c_N (多跑宇宙)
#
# 最优决策定理 (D1-D4):
#   (D1) σ = "unique" 且 孤岛=0 且 无 IO 不等价:
#        a* = release, Cost = 0
#        (唯一解 + 无异常 = 可放行)
#
#   (D2) σ = "unique" 且 有孤岛 或 IO 不等价:
#        a* = review, Cost = c_r
#        (有收敛但有异常 = 审查异常部分)
#
#   (D3) σ = "multi":
#        a* = run_io_test, Cost = c_io
#        (多解 = 跑 IO 等价区分良性/恶性)
#        若 IO 全等价 → a* = release (良性多解)
#        若 有 IO 不等价 → a* = review (恶性多解)
#
#   (D4) σ = "ambiguous":
#        a* = rewrite_prompt, Cost = c_w
#        (歧义 = 重写比 review 更划算, 因 review 面对的是 LLM
#        各写各的, 无共识可审)
#
#   (D5) σ = "degenerate":
#        a* = verify_degenerate, Cost = c_v
#        (警惕 F1: 全宇宙可能同错, 必须人工验证公约正确性)
#
# 决策树:
#   σ=unique?
#     ├─ 孤岛=0 ∧ IO 全等价 → release (D1)
#     └─ 有孤岛或 IO 不等价 → review (D2)
#   σ=multi?
#     ├─ IO 全等价 → release (良性多解)
#     └─ 有 IO 不等价 → review (恶性多解)
#   σ=ambiguous → rewrite_prompt (D4)
#   σ=degenerate → verify_degenerate (D5)
#
# 代价最优性: 上述决策在给定 σ 下最小化 Cost(a, σ),
#             前提是 σ 分类正确 (依赖第 14 节 T1-T4).
#
# 17. N 选择定理 (从 Hoeffding 界推导最少样本量)
# ──────────────────────────────────────────────────────────────
# 第 13 节给出 Hoeffding 界: P(|p̂-p*| ≥ ε) ≤ 2·exp(-2Nε²)
# 令 δ = 2·exp(-2Nε²) (失败概率), 解 N:
#
#   N_min(ε, δ) = ln(2/δ) / (2ε²)
#
# 常用组合:
#   ε=0.1, δ=0.3 → N = ln(2/0.3)/(2·0.01) = ln(6.67)/0.02 ≈ 1.90/0.02 = 95
#   ε=0.15, δ=0.5 → N = ln(4)/(2·0.0225) ≈ 1.39/0.045 = 31
#   ε=0.2, δ=0.5 → N = ln(4)/(2·0.04) ≈ 1.39/0.08 = 17
#   ε=0.2, δ=0.8 → N = ln(2.5)/(0.08) ≈ 0.92/0.08 = 12
#
# 实践指南:
#   N=5:  ε=0.2, δ≈0.8+ (失败概率高, 仅快速冒烟)
#   N=10: ε=0.15, δ≈0.7 (中等可靠)
#   N=20: ε=0.1, δ≈0.7 (精度提升但失败概率仍高)
#   N=50: ε=0.1, δ≈0.18 (接近统计严格)
#   N=95: ε=0.1, δ=0.3 (统计上可信)
#
# 推论 (N 的边际效用递减):
#   N 翻倍 → ε 缩小 √2 倍 (非 2 倍)
#   即: N=10 → N=20, ε 从 0.15 → 0.106 (仅缩小 30%)
#   但成本翻倍 → 边际效用递减, N=5~10 是工程最优区间.
#
# 18. Prompt 质量熵判据 + 闭环收敛性定理
# ──────────────────────────────────────────────────────────────
# 基于 第 15 节熵解释, 定义 prompt 质量的形式化判据:
#
#   质量函数 Q(p) = 1 - H(x|p) / H_max
#     H_max = log|S(p)| (解空间大小的对数, 均匀分布时熵最大)
#   当 |S(p)|=1 时 H=0, Q(p)=1 (理想 prompt: 解空间唯一)
#   当 |S(p)|→∞ 且均匀时 H→H_max, Q(p)→0 (最差 prompt)
#
#   UCS 可视为 Q(p) 的经验估计 (通过 N 次采样).
#
#   实现: prompt_quality(report) -> float  (见 L8** 段)
#     - 对 N 个宇宙的归一化输出做去重, |S(p)| = 去重后解数
#     - 香农熵 H = -Σ (cnt/N) log(cnt/N), H_max = log|S|
#     - Q(p) = 1 - H / H_max, ∈[0,1]
#     - |S|<=1 → Q(p)=1 (唯一解/退化, degenerate 需 D5 验证 F1)
#
# 闭环收敛性定理 (run_until_converged):
#   设 UCS_t 为第 t 轮闭环的 UCS, 改 prompt 的策略为 π:
#     UCS_{t+1} = π(UCS_t, diagnose_t)
#   收敛条件:
#     (CC1) 单调收敛: 若 π 使 UCS_{t+1} ≥ UCS_t (单调不减),
#            则存在 T 使 UCS_T ≥ target (目标达成)
#     (CC2) 振荡检测: 若连续 3 轮 UCS 下降 (UCS_{t+1} < UCS_t),
#            则 π 策略可能振荡 (改 prompt 反而变差), 应停止
#     (CC3) 上界: UCS_t ≤ 1 (不可能超过 1), 故单调序列必有上确界
#
#   实现中 (run_until_converged): 振荡检测默认阈值 3 轮下降,
#   超过则停止 (避免无限循环).
#
# 收敛速度:
#   最坏情况: T = O(1/(target - UCS_0)) (每轮提升固定量)
#   实际: 取决于 LLM 改 prompt 的能力, 通常 T=2~5 轮收敛
#
# 19. PWP-QA 不可证明性定理 + 互补定理
# ──────────────────────────────────────────────────────────────
# 定理 (不可证明性): PWP-QA 不能证明代码正确.
#   证明: 设 f 是某 prompt 的公约数 (所有宇宙都输出 f).
#   若 f 有 bug 但所有宇宙都犯同一个错 (F1 失败模式),
#   则 UCS=1 但 f 仍错误. PWP-QA 无法检测这种"全宇宙同错".
#   ∴ UCS=1 不蕴含 f 正确. PWP-QA 不可证明正确性. ∎
#
# 定理 (不一致性可证): PWP-QA 可以证明代码不一致.
#   证明: 若存在孤岛 f (只在 1 个宇宙出现), 或 IO 不等价分叉
#   (不同宇宙输出对同输入产生不同输出), 则宇宙间不一致.
#   这是直接观察, 不依赖假设. ∴ PWP-QA 可证不一致. ∎
#
# 互补定理 (PWP-QA 与形式化验证):
#   设 V(f) 为形式化验证 (证明 f 满足规约 spec),
#       P(f) = PWP-QA 判定 (UCS + IO 等价).
#   则:
#     (CT1) V(f)=✓ ⟹ 不需要 P(f) (已证明正确)
#     (CT2) V(f)=✗ ⟹ P(f) 应标记 f 为孤岛 (验证发现的 bug)
#     (CT3) P(f) UCS=1 且 IO 全等价 ⟹ V(f) 可能 ✓ 或 ✗
#           (PWP 不能区分, 需 V 补充)
#     (CT4) P(f) 有孤岛 ⟹ V(f) 应针对孤岛验证 (聚焦验证)
#
#   工作流: PWP-QA 先跑 → 把孤岛+IO 不等价分叉交给形式化验证
#   → 比"全量形式化验证"成本低 (只验高风险部分).
#
# 推广定理 (PWP-QA 对任意生成式系统):
#   PWP-QA 不限于 LLM 代码生成. 对任意生成式系统 G:
#     - G 有随机性 (temperature/seed/dropout)
#     - G 的输出可被三分 (公约/分叉/孤岛)
#     - G 的输出可做 IO 等价测试
#   则 PWP-QA 适用. 包括:
#     - LLM 代码生成 (当前应用)
#     - LLM 文本生成 (三分=句子/段落级, IO=语义等价)
#     - 扩散模型图像生成 (三分=构图/风格/异常, IO=感知等价)
#     - 遗传算法/进化策略 (三分=基因型, IO=适应度等价)
#   限制: 需要可定义"等价"的输出空间 (代码可执行, 文本可比较).
# ══════════════════════════════════════════════════════════════

__all__ = [
    "Universe",
    "generate_universes",
    "generate_universes_async",
    "Triage",
    "triage_universes",
    "FunctionDef",
    "FunctionVariant",
    "FunctionTriage",
    "parse_functions",
    "triage_universes_ast",
    "QASignal",
    "extract_qa_signal",
    "Metrics",
    "compute_metrics",
    "PWPReport",
    "run",
    "run_async",
    "make_openai_generator",
    "make_anthropic_generator",
    "make_ollama_generator",
    "LLM_CACHE_DIR",
    "TestCase",
    "run_function_test",
    "generate_test_suite",
    "suggest_prompt_improvements",
    "classify_solution_space",
    "establish_baseline",
    "load_baseline",
    "detect_drift",
    "drift_report_markdown",
    "BASELINE_PROMPTS",
    "compare_models",
    "compare_models_markdown",
    "auto_rewrite_prompt",
    "Decision",
    "decide",
    "n_min",
    "prompt_quality",
    "FormalVerificationResult",
    "FormalVerificationPlan",
    "ct1_should_skip_pwp",
    "ct2_mark_verified_bugs",
    "ct3_needs_verification",
    "ct4_focus_verification_targets",
    "plan_formal_verification",
    "DEFAULT_COSTS",
    "TREND_LOG_PATH",
    "log_run_to_trend",
    "load_trend",
    "trend_to_markdown",
    "ConvergenceIteration",
    "ConvergenceReport",
    "convergence_speed",
    "run_until_converged",
]

GeneratorFn = Callable[[str, Optional[int]], str]

# ──────────────────────────────────────────────────────────────
# L0 成本缓存 (Cost Cache)  —— 工程支撑层, 非方法论核心
# 同 (model, prompt, seed) hash 命中本地 json 缓存, 省掉重复 API 调用.
# 概念定位: 优化采样成本, 不影响 PWP-QA 的方法论结论.
# ──────────────────────────────────────────────────────────────

LLM_CACHE_DIR = Path(
    os.environ.get("PWP_QA_CACHE_DIR", Path.home() / ".pwp_qa_cache")
)


def _cache_key(model: str, prompt: str, seed: Optional[int]) -> str:
    """sha256(model + prompt + seed) -> 缓存文件名"""
    h = hashlib.sha256()
    h.update(model.encode("utf-8"))
    h.update(b"\x00")
    h.update(prompt.encode("utf-8"))
    h.update(b"\x00")
    h.update(str(seed).encode("utf-8"))
    return h.hexdigest()


def _cache_read(key: str) -> Optional[str]:
    """读缓存; 不存在或损坏返回 None"""
    path = LLM_CACHE_DIR / f"{key}.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data.get("code")
    except Exception:
        return None


def _cache_write(key: str, code: str, model: str) -> None:
    """写缓存; 失败静默 (缓存不是关键路径)"""
    try:
        LLM_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        path = LLM_CACHE_DIR / f"{key}.json"
        path.write_text(
            json.dumps(
                {
                    "code": code,
                    "model": model,
                    "ts": time.time(),
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
    except Exception:
        pass


# ──────────────────────────────────────────────────────────────
# L0** 阈值校准 (Threshold Calibration)  —— 工程支撑层
# 从 thresholds.json 加载经验拟合阈值 (由 calibration.py 生成)
# 加载失败回退默认值 0.6, 保证无校准时框架行为不变
# ──────────────────────────────────────────────────────────────

# 默认阈值 (校准前的回退值)
DEFAULT_THRESHOLDS = {
    "ucs_converged": 0.6,        # UCS>=此值视为收敛
    "ucs_review": 0.3,           # UCS>=此值进入 review, <此值必须改 prompt
    "drift": 0.15,               # UCS 漂移阈值 (绝对差)
    "outlier_severity": 0.1,     # 孤岛严重度阈值
}

# 内存缓存 (只加载一次)
_thresholds_cache: Optional[dict] = None


def load_thresholds(refresh: bool = False) -> dict:
    """加载经验拟合阈值 (从 thresholds.json).

    搜索顺序:
      1. $PWP_QA_THRESHOLDS_PATH (显式指定)
      2. 当前目录 thresholds.json
      3. ~/.pwp_qa_cache/thresholds.json
      4. 包目录 thresholds.json (随包发布的预设)

    任何加载失败都静默回退 DEFAULT_THRESHOLDS, 不影响框架运行.
    """
    global _thresholds_cache
    if _thresholds_cache is not None and not refresh:
        return _thresholds_cache

    import os as _os
    # 显式禁用校准: 回退默认
    if _os.environ.get("PWP_QA_DISABLE_CALIBRATION"):
        _thresholds_cache = dict(DEFAULT_THRESHOLDS)
        _thresholds_cache["_source"] = "disabled"
        return _thresholds_cache

    candidates = []

    env_path = _os.environ.get("PWP_QA_THRESHOLDS_PATH")
    if env_path:
        candidates.append(Path(env_path))

    candidates.append(Path("thresholds.json"))
    candidates.append(LLM_CACHE_DIR / "thresholds.json")
    # 包目录 (随包发布的预设)
    try:
        candidates.append(Path(__file__).parent / "thresholds.json")
    except Exception:
        pass

    for path in candidates:
        try:
            if not path.exists():
                continue
            data = json.loads(path.read_text(encoding="utf-8"))
            # 合并: 缺失字段用默认值填充
            merged = dict(DEFAULT_THRESHOLDS)
            if "threshold" in data:
                merged["ucs_converged"] = float(data["threshold"])
            if "threshold_ci" in data and isinstance(data["threshold_ci"], list):
                merged["threshold_ci"] = [
                    float(x) for x in data["threshold_ci"]
                ]
            # 允许直接覆盖
            for k in ("ucs_review", "drift", "outlier_severity"):
                if k in data:
                    merged[k] = float(data[k])
            # 透传校准元数据 (版本管理用)
            for k in ("model", "prompt_set", "n_samples", "n_pos", "n_neg",
                      "auc", "youden_j", "calibrated_at", "threshold_ci",
                      "bhattacharyya", "separation"):
                if k in data:
                    merged[k] = data[k]
            merged["_source"] = str(path)
            _thresholds_cache = merged
            return merged
        except Exception:
            continue

    # 全部失败, 回退默认
    _thresholds_cache = dict(DEFAULT_THRESHOLDS)
    _thresholds_cache["_source"] = "default"
    return _thresholds_cache


# ──────────────────────────────────────────────────────────────
# L0* 历史趋势追踪 (Trend Tracking)  —— 工程支撑层, 非方法论核心
# 每次 run() 写一行 JSONL 到 ~/.pwp_qa_cache/trend.jsonl
# 跨次可见 UCS 趋势, 判断迭代是否在变好.
# 概念定位: 观察方法论效果的长期变化, 不参与单次 triage 计算.
# ──────────────────────────────────────────────────────────────

TREND_LOG_PATH = LLM_CACHE_DIR / "trend.jsonl"


def log_run_to_trend(report: "PWPReport", extra: Optional[dict] = None) -> None:
    """
    把一次 run 的关键度量追加到 trend.jsonl (静默失败)

    字段: ts, prompt_sha8, ucs, robustness, convergence, n, level, io_tested,
          has_suggestions
    """
    try:
        LLM_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        sha8 = hashlib.sha256(report.prompt.encode("utf-8")).hexdigest()[:8]
        record = {
            "ts": time.time(),
            "prompt_sha8": sha8,
            "ucs": round(report.metrics.ucs, 4),
            "robustness": round(report.metrics.robustness, 4),
            "convergence": round(report.metrics.convergence, 4),
            "n": report.metrics.n,
            "level": report.level,
            "io_tested": report.io_tested,
            "has_suggestions": bool(report.prompt_suggestions),
            "solution_space": report.metrics.solution_space,
        }
        if extra:
            record.update(extra)
        with open(TREND_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except Exception:
        pass


def load_trend(limit: int = 100) -> List[dict]:
    """
    读最近 N 条 trend 记录 (最旧的在前, 按时间顺序)

    损坏行静默跳过
    """
    if not TREND_LOG_PATH.exists():
        return []
    records: List[dict] = []
    try:
        with open(TREND_LOG_PATH, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except Exception:
                    continue
    except Exception:
        return []
    return records[-limit:] if limit > 0 else records


def trend_to_markdown(limit: int = 20) -> str:
    """
    表格化展示最近 N 次 run 的 UCS 趋势

    列: # | 时间 | UCS | 鲁棒性 | 收敛度 | N | 层级 |  ↗↘→ (与上条比)
    """
    records = load_trend(limit)
    if not records:
        return "## 历史趋势\n\n(暂无记录; 跑一次 run() 即开始追踪)\n"

    out: List[str] = ["## 历史趋势 (最近 " + str(len(records)) + " 次 run)", ""]
    out.append(
        "| # | 时间 | UCS | 鲁棒性 | 收敛度 | 解空间 | N | 层级 | IO 测 | 趋势 |"
    )
    out.append("|---|------|-----|--------|--------|--------|---|------|-------|------|")
    prev_ucs: Optional[float] = None
    for i, r in enumerate(records, 1):
        ucs = r.get("ucs", 0.0)
        if prev_ucs is None:
            arrow = "—"
        else:
            diff = ucs - prev_ucs
            if diff > 0.01:
                arrow = "↗"
            elif diff < -0.01:
                arrow = "↘"
            else:
                arrow = "→"
        prev_ucs = ucs
        ts = r.get("ts", 0)
        ts_str = time.strftime("%m-%d %H:%M", time.localtime(ts)) if ts else "-"
        space = r.get("solution_space", "-")
        out.append(
            f"| {i} | {ts_str} | {ucs:.3f} | {r.get('robustness', 0):.3f} | "
            f"{r.get('convergence', 0):.3f} | {space} | {r.get('n', '-')} | "
            f"{r.get('level', '-')} | {'✓' if r.get('io_tested') else '-'} | {arrow} |"
        )
    out.append("")
    out.append(
        f"**最终 UCS**: {records[-1].get('ucs', 0):.3f}  "
        f"(共 {len(records)} 条记录)"
    )

    # 统计摘要 (L0* 诊断层)
    stats = trend_stats(records)
    if stats:
        out.append("")
        out.append("### 统计摘要")
        out.append(
            f"- UCS 均值: `{stats['ucs_mean']:.3f}`  "
            f"(标准差 `{stats['ucs_std']:.3f}`)"
        )
        out.append(
            f"- 鲁棒性均值: `{stats['robustness_mean']:.3f}`  "
            f"收敛度均值: `{stats['convergence_mean']:.3f}`"
        )
        out.append(
            f"- 趋势方向: **{stats['direction']}**  "
            f"(线性斜率 {stats['slope']:+.4f}/次)"
        )
        _thr_display = load_thresholds().get("ucs_converged", 0.6)
        out.append(
            f"- 收敛率: `{stats['converged_rate']:.0%}` "
            f"({stats['converged_count']}/{len(records)} 次 UCS>={_thr_display})"
        )
    return "\n".join(out)


def trend_stats(records: Optional[List[dict]] = None) -> Optional[dict]:
    """
    L0* 诊断层: 对 trend 记录做统计, 回答"prompt 在变好还是变差".

    返回 dict (记录不足时返回 None):
      ucs_mean / ucs_std       UCS 均值与总体标准差
      robustness_mean          鲁棒性均值
      convergence_mean         收敛度均值
      slope                    UCS 对序号的线性回归斜率 (每次 run 的变化量)
      direction                "上升" | "下降" | "平稳"
      converged_count / rate   UCS>=阈值 的次数与占比
    """
    if records is None:
        records = load_trend(100)
    n = len(records)
    if n < 2:
        return None

    ucs_list = [r.get("ucs", 0.0) for r in records]
    rob_list = [r.get("robustness", 0.0) for r in records]
    conv_list = [r.get("convergence", 0.0) for r in records]

    ucs_mean = sum(ucs_list) / n
    ucs_var = sum((x - ucs_mean) ** 2 for x in ucs_list) / n
    ucs_std = ucs_var ** 0.5

    # 简单线性回归: UCS = slope * i + intercept
    xs = list(range(n))
    x_mean = (n - 1) / 2.0
    y_mean = ucs_mean
    num = sum((xs[i] - x_mean) * (ucs_list[i] - y_mean) for i in range(n))
    den = sum((x - x_mean) ** 2 for x in xs) or 1.0
    slope = num / den

    if slope > 0.01:
        direction = "上升"
    elif slope < -0.01:
        direction = "下降"
    else:
        direction = "平稳"

    ucs_thr = load_thresholds().get("ucs_converged", 0.6)
    converged_count = sum(1 for u in ucs_list if u >= ucs_thr)

    return {
        "ucs_mean": ucs_mean,
        "ucs_std": ucs_std,
        "robustness_mean": sum(rob_list) / n,
        "convergence_mean": sum(conv_list) / n,
        "slope": slope,
        "direction": direction,
        "converged_count": converged_count,
        "converged_rate": converged_count / n,
    }


# ──────────────────────────────────────────────────────────────
# 连续基线 (Continuous Baseline) — 阶梯 2
# 定期跑标准 prompt 集, 建立 UCS 基线, 检测漂移 (模型更新导致质量退化)
# ──────────────────────────────────────────────────────────────

# 标准基线 prompt 集 (5 个, 全部是明确函数级 prompt, 确保可重复快速跑完)
BASELINE_PROMPTS: List[str] = [
    "写一个 Python 函数 add(a, b), 返回 a+b. 只输出代码.",
    "写一个计算器模块: add/sub/mul/div 四个函数. "
    "div 在 b==0 时抛 ZeroDivisionError. 只输出代码.",
    "写 quicksort(arr: list) -> list, 返回升序排序后的新列表 (非原地). 只输出代码.",
    "写一个 Python 函数 is_palindrome(s: str) -> bool, 判断字符串是否为回文. 只输出代码.",
    "写一个 Python 函数 is_prime(n: int) -> bool, 判断 n 是否为素数. 只输出代码.",
]

# 基线文件路径 (与 trend.jsonl 同目录)
BASELINE_PATH = LLM_CACHE_DIR / "baseline.json"


def _retry_gen(generator: GeneratorFn, max_retries: int = 4,
               timeout: int = 90) -> GeneratorFn:
    """给 generator 套重试 + 超时 (供 baseline/drift 使用)."""
    import concurrent.futures

    def wrapped(prompt: str, seed: int | None = None) -> str:
        for attempt in range(max_retries):
            try:
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
                    fut = ex.submit(generator, prompt, seed)
                    return fut.result(timeout=timeout)
            except concurrent.futures.TimeoutError:
                if attempt == max_retries - 1:
                    raise RuntimeError(f"API 调用超时 ({timeout}s)")
                time.sleep(2 ** attempt)
            except Exception as e:
                msg = str(e)
                transient = any(c in msg for c in ("502", "503", "504",
                                                   "429", "500"))
                if not transient or attempt == max_retries - 1:
                    raise
                time.sleep(2 ** attempt)
        return ""
    return wrapped


def establish_baseline(
    generator: GeneratorFn,
    n: int = 5,
    level: str = "ast",
    prompts: Optional[List[str]] = None,
) -> dict:
    """
    建立基线: 对每个基线 prompt 跑一次 run(), 记录 UCS/解空间分类.

    Returns: {"prompts": [...], "established_at": ts, "results": [...]}
    结果存到 baseline.json, 后续 drift_detect 会对比.
    """
    prompts = prompts or BASELINE_PROMPTS
    gen = _retry_gen(generator)
    results = []
    for i, prompt in enumerate(prompts):
        print(f"  [基线 {i+1}/{len(prompts)}] {prompt[:40]}...", flush=True)
        try:
            report = run(prompt, gen, n=n, level=level)
            results.append({
                "prompt": prompt,
                "prompt_sha8": hashlib.sha256(
                    prompt.encode("utf-8")
                ).hexdigest()[:8],
                "ucs": round(report.metrics.ucs, 4),
                "robustness": round(report.metrics.robustness, 4),
                "convergence": round(report.metrics.convergence, 4),
                "solution_space": report.metrics.solution_space,
                "n": n,
                "level": level,
            })
        except Exception as e:
            results.append({
                "prompt": prompt,
                "error": str(e)[:200],
            })

    baseline = {
        "established_at": time.time(),
        "model_info": getattr(generator, "__name__", "unknown"),
        "n": n,
        "level": level,
        "results": results,
    }
    try:
        LLM_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        with open(BASELINE_PATH, "w", encoding="utf-8") as f:
            json.dump(baseline, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
    return baseline


def load_baseline() -> Optional[dict]:
    """读取已建立的基线. 无则返回 None."""
    if not BASELINE_PATH.exists():
        return None
    try:
        with open(BASELINE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def detect_drift(
    generator: GeneratorFn,
    n: int = 5,
    level: str = "ast",
    threshold: Optional[float] = None,
) -> dict:
    """
    漂移检测: 对比当前 run 结果与基线, 检测 UCS 是否漂移.

    threshold 默认从 load_thresholds() 读取 (默认 0.15).

    Args:
        threshold: UCS 漂移阈值 (绝对差), 默认 0.15

    Returns: {
        "has_drift": bool,
        "baseline_at": ts,
        "checked_at": ts,
        "per_prompt": [{"prompt": ..., "baseline_ucs": ..., "current_ucs": ...,
                        "delta": ..., "drifted": bool, "space_changed": bool}],
        "summary": "无漂移" / "N 个 prompt 发生漂移",
    }
    """
    baseline = load_baseline()
    if not baseline:
        return {
            "has_drift": False,
            "error": "未建立基线; 先跑 establish_baseline()",
        }

    if threshold is None:
        threshold = load_thresholds().get("drift", 0.15)

    baseline_results = baseline.get("results", [])
    gen = _retry_gen(generator)
    per_prompt = []
    drift_count = 0

    for i, bl in enumerate(baseline_results):
        prompt = bl.get("prompt", "")
        bl_ucs = bl.get("ucs", 0.0)
        bl_space = bl.get("solution_space", "unknown")
        print(f"  [漂移检测 {i+1}/{len(baseline_results)}] {prompt[:40]}...",
              flush=True)
        try:
            report = run(prompt, gen, n=n, level=level)
            cur_ucs = round(report.metrics.ucs, 4)
            cur_space = report.metrics.solution_space
            delta = round(cur_ucs - bl_ucs, 4)
            drifted = abs(delta) > threshold
            space_changed = bl_space != cur_space
            if drifted:
                drift_count += 1
            per_prompt.append({
                "prompt": prompt[:60],
                "baseline_ucs": bl_ucs,
                "current_ucs": cur_ucs,
                "delta": delta,
                "drifted": drifted,
                "baseline_space": bl_space,
                "current_space": cur_space,
                "space_changed": space_changed,
            })
        except Exception as e:
            per_prompt.append({
                "prompt": prompt[:60],
                "error": str(e)[:200],
            })

    return {
        "has_drift": drift_count > 0,
        "drift_count": drift_count,
        "baseline_at": baseline.get("established_at", 0),
        "checked_at": time.time(),
        "threshold": threshold,
        "per_prompt": per_prompt,
        "summary": (
            f"{drift_count} 个 prompt 发生漂移 (阈值={threshold})"
            if drift_count > 0
            else f"无漂移 (所有 prompt UCS 变化 < {threshold})"
        ),
    }


def drift_report_markdown(drift_result: dict) -> str:
    """把漂移检测结果格式化为 markdown."""
    if "error" in drift_result:
        return f"## 漂移检测\n\n⚠ {drift_result['error']}\n"

    out: List[str] = ["## 漂移检测 (Continuous Baseline)", ""]

    bl_ts = drift_result.get("baseline_at", 0)
    ck_ts = drift_result.get("checked_at", 0)
    bl_str = time.strftime("%Y-%m-%d %H:%M", time.localtime(bl_ts)) if bl_ts else "-"
    ck_str = time.strftime("%Y-%m-%d %H:%M", time.localtime(ck_ts)) if ck_ts else "-"
    out.append(f"基线建立: **{bl_str}**  检测时间: **{ck_str}**")
    out.append(f"漂移阈值: `{drift_result.get('threshold', 0.15)}`")
    out.append("")

    if drift_result.get("has_drift"):
        out.append(
            f"⚠ **{drift_result['drift_count']} 个 prompt 发生漂移**")
    else:
        out.append("✓ **无漂移** — 所有 prompt UCS 稳定")
    out.append("")

    out.append("| # | Prompt | 基线UCS | 当前UCS | Δ | 漂移? | 基线解空间 | 当前解空间 | 解空间变? |")
    out.append("|---|--------|---------|---------|---|-------|-----------|-----------|----------|")
    for i, p in enumerate(drift_result.get("per_prompt", []), 1):
        if "error" in p:
            out.append(f"| {i} | {p['prompt']} | - | - | - | ERROR | - | - | - |")
            continue
        delta = p.get("delta", 0)
        delta_str = f"{delta:+.3f}"
        drift_flag = "⚠ 漂移" if p.get("drifted") else "✓"
        space_flag = "✓ 变" if p.get("space_changed") else "-"
        out.append(
            f"| {i} | {p['prompt']} | {p['baseline_ucs']:.3f} | "
            f"{p['current_ucs']:.3f} | {delta_str} | {drift_flag} | "
            f"{p.get('baseline_space', '-')} | "
            f"{p.get('current_space', '-')} | {space_flag} |"
        )

    out.append("")
    out.append(f"**结论**: {drift_result.get('summary', '-')}")
    out.append("")
    out.append(
        "漂移可能原因: 模型版本更新 / API 端点变更 / "
        "prompt 语义环境变化 (如新库流行度影响 LLM 偏好)"
    )
    return "\n".join(out)


# ──────────────────────────────────────────────────────────────
# 多模型对比 (Multi-Model Comparison) — 阶梯 2 扩展
# 同一基线 prompt 跑不同模型, 对比 UCS 分布
# ──────────────────────────────────────────────────────────────

def compare_models(
    prompt: str,
    generators: dict,
    n: int = 5,
    level: str = "ast",
) -> dict:
    """
    对同一 prompt 跑多个模型, 对比 UCS/解空间分布.

    Args:
        prompt: 要测试的 prompt
        generators: {model_name: GeneratorFn} 字典
        n: 每个模型跑几个宇宙
        level: 对齐层级

    Returns: {
        "prompt": prompt,
        "models": [
            {"name": model_name, "ucs": ..., "robustness": ...,
             "convergence": ..., "solution_space": ...,
             "error": None or str},
            ...
        ],
        "best_model": model_name,  # UCS 最高的
        "most_stable": model_name, # 鲁棒性最高的
    }
    """
    results = []
    for name, gen in generators.items():
        print(f"  [对比] {name}: {prompt[:40]}...", flush=True)
        try:
            gen_wrapped = _retry_gen(gen)
            report = run(prompt, gen_wrapped, n=n, level=level)
            results.append({
                "name": name,
                "ucs": round(report.metrics.ucs, 4),
                "robustness": round(report.metrics.robustness, 4),
                "convergence": round(report.metrics.convergence, 4),
                "solution_space": report.metrics.solution_space,
                "outliers": len(report.triage.outliers),
                "branching": len(report.triage.branching),
                "error": None,
            })
        except Exception as e:
            results.append({
                "name": name,
                "ucs": 0.0,
                "robustness": 0.0,
                "convergence": 0.0,
                "solution_space": "error",
                "outliers": 0,
                "branching": 0,
                "error": str(e)[:200],
            })

    # 找最佳
    valid = [r for r in results if r["error"] is None]
    best = max(valid, key=lambda r: r["ucs"]) if valid else None
    stable = max(valid, key=lambda r: r["robustness"]) if valid else None

    return {
        "prompt": prompt,
        "n": n,
        "level": level,
        "models": results,
        "best_model": best["name"] if best else None,
        "most_stable": stable["name"] if stable else None,
    }


def compare_models_markdown(result: dict) -> str:
    """多模型对比结果 -> markdown."""
    out: List[str] = ["## 多模型对比 (Multi-Model Comparison)", ""]
    out.append(f"Prompt: `{result['prompt'][:60]}...`")
    out.append(f"N={result['n']}, level={result['level']}")
    out.append("")

    out.append("| 模型 | UCS | 鲁棒性 | 收敛度 | 解空间 | 孤岛 | 分叉 | 状态 |")
    out.append("|------|-----|--------|--------|--------|------|------|------|")
    for m in result.get("models", []):
        if m.get("error"):
            out.append(f"| {m['name']} | - | - | - | - | - | - | ❌ {m['error'][:30]} |")
        else:
            _ucs_thr = load_thresholds().get("ucs_converged", 0.6)
            ucs_color = "🟢" if m["ucs"] >= _ucs_thr else "🔴"
            out.append(
                f"| {m['name']} | {ucs_color} {m['ucs']:.3f} | "
                f"{m['robustness']:.3f} | {m['convergence']:.3f} | "
                f"{m['solution_space']} | {m['outliers']} | "
                f"{m['branching']} | ✅ |"
            )

    out.append("")
    if result.get("best_model"):
        out.append(f"**UCS 最高**: `{result['best_model']}`")
    if result.get("most_stable"):
        out.append(f"**最稳定 (鲁棒性最高)**: `{result['most_stable']}`")
    out.append("")
    out.append("解读: UCS 高 = 模型对 prompt 理解一致; "
              "解空间=multi = 多解(非模型差异); "
              "解空间=ambiguous = prompt 有歧义(各模型都发散).")
    return "\n".join(out)


# ──────────────────────────────────────────────────────────────
# L1 宇宙生成 (Universe Generation)
# ──────────────────────────────────────────────────────────────

@dataclass
class Universe:
    """一个平行宇宙 = 一次 LLM 生成的代码"""
    id: int
    code: str
    seed: Optional[int] = None
    latency: float = 0.0

    def __repr__(self) -> str:
        return f"Universe(id={self.id}, seed={self.seed}, lines={len(self.code.splitlines())}, {self.latency:.2f}s)"


def generate_universes(
    prompt: str,
    generator: GeneratorFn,
    n: int = 5,
    seeds: Optional[List[int]] = None,
) -> List[Universe]:
    """
    生成 N 个平行宇宙

    Args:
        prompt:     提示词 P (固定)
        generator:  调用 LLM 的函数 (prompt, seed) -> code
        n:          宇宙数量 (推荐 3 经济 / 5 标准 / 10 严格)
        seeds:      可选 seed 列表; None 时随机生成

    铁律: 差异必须来自采样随机性, 不能来自 prompt 模糊
    """
    if seeds is None:
        seeds = [random.randint(0, 2**31 - 1) for _ in range(n)]
    if len(seeds) != n:
        raise ValueError(f"seeds 数量 ({len(seeds)}) != n ({n})")

    universes: List[Universe] = []
    for i, seed in enumerate(seeds):
        t0 = time.time()
        code = generator(prompt, seed)
        universes.append(Universe(
            id=i + 1,
            code=code,
            seed=seed,
            latency=time.time() - t0,
        ))
    return universes


async def generate_universes_async(
    prompt: str,
    generator: Callable[..., Any],
    n: int = 5,
    seeds: Optional[List[int]] = None,
    concurrency: int = 5,
) -> List[Universe]:
    """
    异步并发生成 N 个平行宇宙

    generator 可以是:
      - async callable (prompt, seed) -> str
      - 同步 callable (会被 asyncio.to_thread 包装)

    concurrency: asyncio.Semaphore 限流, 默认 5 (避免打爆 rate limit)
    """
    import asyncio

    if seeds is None:
        seeds = [random.randint(0, 2**31 - 1) for _ in range(n)]
    if len(seeds) != n:
        raise ValueError(f"seeds 数量 ({len(seeds)}) != n ({n})")

    sem = asyncio.Semaphore(concurrency)

    async def _call_one(idx: int, seed: int) -> Universe:
        async with sem:
            t0 = time.time()
            if asyncio.iscoroutinefunction(generator):
                code = await generator(prompt, seed)
            else:
                code = await asyncio.to_thread(generator, prompt, seed)
            return Universe(
                id=idx + 1,
                code=code,
                seed=seed,
                latency=time.time() - t0,
            )

    tasks = [_call_one(i, s) for i, s in enumerate(seeds)]
    return await asyncio.gather(*tasks)


# ──────────────────────────────────────────────────────────────
# L1* 真实 LLM 工厂 (Real LLM Generators)
# ──────────────────────────────────────────────────────────────
#
# 工厂函数返回 (prompt, seed) -> str 签名的 generator, 与
# mock_generator 完全兼容, run/generate_universes 无需改造.
#
# 缓存策略: 同 (model, prompt, seed) 命中本地 json, 跳过 API 调用
# ──────────────────────────────────────────────────────────────


def _wrap_cached(
    model: str,
    raw_call: Callable[[str, Optional[int]], str],
) -> GeneratorFn:
    """把 raw LLM 调用包一层缓存"""
    def cached_generator(prompt: str, seed: Optional[int] = None) -> str:
        key = _cache_key(model, prompt, seed)
        cached = _cache_read(key)
        if cached is not None:
            return cached
        code = raw_call(prompt, seed)
        _cache_write(key, code, model)
        return code
    return cached_generator


def make_openai_generator(
    model: str = "gpt-4o-mini",
    temperature: float = 0.7,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    system_prompt: str = "You are a Python code generator. Output ONLY Python code, no markdown fences, no explanations.",
) -> GeneratorFn:
    """
    OpenAI 兼容 generator 工厂 (也支持 OpenRouter / DeepSeek / Moonshot 等 OpenAI 兼容端点)

    Args:
        model:        模型名 (gpt-4o-mini / gpt-4o / deepseek-coder / ...)
        temperature:  采样温度, >0 引入随机性 (PWP-QA 必须用 >0 才能产生多宇宙)
        api_key:      API key; None 时读 OPENAI_API_KEY env
        base_url:     兼容端点; None 时读 OPENAI_BASE_URL env (OpenAI 官方)
        system_prompt: 系统提示, 默认要求纯代码输出
    """
    if not _OPENAI_AVAILABLE:
        raise ImportError(
            "openai 未安装; pip install openai (或 OpenAI 兼容客户端)"
        )
    api_key = api_key or os.environ.get("OPENAI_API_KEY")
    base_url = base_url or os.environ.get("OPENAI_BASE_URL")
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY 未设置; export OPENAI_API_KEY=sk-..."
        )

    client = _openai.OpenAI(api_key=api_key, base_url=base_url)

    def _raw(prompt: str, seed: Optional[int] = None) -> str:
        # 把 seed 编进 user prompt, 让 LLM 据此产生差异
        seed_str = f" (random_seed={seed})" if seed is not None else ""
        resp = client.chat.completions.create(
            model=model,
            temperature=temperature,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"{prompt}{seed_str}"},
            ],
            timeout=90,
        )
        return resp.choices[0].message.content or ""

    return _wrap_cached(model, _raw)


def make_anthropic_generator(
    model: str = "claude-3-5-haiku-20241022",
    temperature: float = 0.7,
    api_key: Optional[str] = None,
    system_prompt: str = "You are a Python code generator. Output ONLY Python code, no markdown fences, no explanations.",
) -> GeneratorFn:
    """Anthropic Claude generator 工厂"""
    if not _ANTHROPIC_AVAILABLE:
        raise ImportError("anthropic 未安装; pip install anthropic")
    api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise RuntimeError("ANTHROPIC_API_KEY 未设置")

    client = _anthropic.Anthropic(api_key=api_key)

    def _raw(prompt: str, seed: Optional[int] = None) -> str:
        seed_str = f" (random_seed={seed})" if seed is not None else ""
        msg = client.messages.create(
            model=model,
            max_tokens=2048,
            temperature=temperature,
            system=system_prompt,
            messages=[{"role": "user", "content": f"{prompt}{seed_str}"}],
        )
        # msg.content 是 list[block], 取 text 块拼起来
        chunks = []
        for block in msg.content:
            if hasattr(block, "text"):
                chunks.append(block.text)
        return "\n".join(chunks)

    return _wrap_cached(model, _raw)


def make_ollama_generator(
    model: str = "qwen2.5-coder:7b",
    temperature: float = 0.7,
    host: Optional[str] = None,
    system_prompt: str = "You are a Python code generator. Output ONLY Python code, no markdown fences, no explanations.",
) -> GeneratorFn:
    """
    Ollama 本地 generator 工厂 (走 REST API, 无需 SDK)

    Args:
        model:  Ollama 拉取的模型名 (qwen2.5-coder / deepseek-coder / ...)
        host:   Ollama host; None 时读 OLLAMA_HOST env, 默认 http://localhost:11434
        temperature: >0 引入采样随机性
    """
    if not _HTTPX_AVAILABLE:
        raise ImportError("httpx 未安装; pip install httpx")
    host = host or os.environ.get("OLLAMA_HOST", "http://localhost:11434")
    host = host.rstrip("/")

    def _raw(prompt: str, seed: Optional[int] = None) -> str:
        seed_str = f" (random_seed={seed})" if seed is not None else ""
        # Ollama /api/chat 端点; 同步阻塞调用
        with _httpx.Client(timeout=120.0) as client:
            r = client.post(
                f"{host}/api/chat",
                json={
                    "model": model,
                    "temperature": temperature,
                    "stream": False,
                    "options": {"seed": seed or 0},
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": f"{prompt}{seed_str}"},
                    ],
                },
            )
            r.raise_for_status()
            data = r.json()
            return data.get("message", {}).get("content", "")

    return _wrap_cached(model, _raw)


# ──────────────────────────────────────────────────────────────
# L2 宇宙对齐 (Universe Alignment)
# ──────────────────────────────────────────────────────────────

def align_literal(a: str, b: str) -> float:
    """字面层相似度 (0..1), 基于 SequenceMatcher"""
    return difflib.SequenceMatcher(None, a, b).ratio()


def align_lines(a: str, b: str) -> List[Tuple[str, str]]:
    """行级对齐, 返回对齐行对 (含 replace)"""
    a_lines = a.splitlines()
    b_lines = b.splitlines()
    matcher = difflib.SequenceMatcher(None, a_lines, b_lines)
    pairs: List[Tuple[str, str]] = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            for i, j in zip(range(i1, i2), range(j1, j2)):
                pairs.append((a_lines[i], b_lines[j]))
        elif tag == "replace":
            for i, j in zip(range(i1, i2), range(j1, j2)):
                la = a_lines[i] if i < len(a_lines) else ""
                lb = b_lines[j] if j < len(b_lines) else ""
                pairs.append((la, lb))
    return pairs


def align_semantic(
    a: str,
    b: str,
    test_fn: Optional[Callable[[str], bool]] = None,
) -> float:
    """
    语义层 (IO 等价性)
    无测试函数时退化为字面相似度
    """
    if test_fn is None:
        return align_literal(a, b)
    try:
        passed_a = test_fn(a)
        passed_b = test_fn(b)
        return 1.0 if (passed_a and passed_b) else 0.0
    except Exception:
        return 0.0


def alignment_matrix(universes: List[Universe]) -> List[List[float]]:
    """对齐矩阵 A[i,j] = 字面相似度"""
    n = len(universes)
    matrix = [[1.0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            sim = align_literal(universes[i].code, universes[j].code)
            matrix[i][j] = sim
            matrix[j][i] = sim
    return matrix


# ──────────────────────────────────────────────────────────────
# L2.5 语义层 IO 等价 (Semantic IO Equivalence)
# ──────────────────────────────────────────────────────────────
#
# L2 字面/行对齐只看"长得像不像". 但同一意图的代码可能写法
# 完全不同 (e.g. `return a * b` vs `result = a * b; return result`).
# L2.5 用 IO 测试套件判定"行为是否等价":
#   - 同一函数的不同变体, 跑同一组 (input, expected) 用例
#   - 全过 -> io_equivalent=True (风格差异, 可接受)
#   - 任一变体失败 -> io_equivalent=False (真 bug, 必须 review)
#
# 测试套件来源:
#   1. 用户提供 (run/test_fn 参数)
#   2. LLM 生成 (generate_test_suite, 需要 generator)
#   3. 启发式 fallback (无 LLM 时, 用默认数值测一遍)
# ──────────────────────────────────────────────────────────────


@dataclass
class TestCase:
    """单个 IO 测试用例"""
    inputs: Tuple[Any, ...]              # 位置参数
    expected: Any                        # 期望返回值 (或期望抛出的异常类型)
    expected_raises: Optional[str] = None  # 非 None 时表示应抛此异常类名
    description: str = ""


def run_function_test(
    fn_code: str,
    fn_name: str,
    test_cases: List[TestCase],
) -> Tuple[int, int, List[str]]:
    """
    在隔离 namespace 中 exec fn_code, 跑 test_cases

    Returns:
      (passed, total, failures)
      failures 是人类可读的失败描述列表
    """
    ns: dict = {}
    failures: List[str] = []
    try:
        exec(fn_code, {"__name__": "__test__"}, ns)
    except Exception as e:
        # 代码本身有语法错或顶层异常 -> 全部失败
        for i, tc in enumerate(test_cases):
            failures.append(f"case {i}: exec 失败 - {type(e).__name__}: {e}")
        return 0, len(test_cases), failures

    fn = ns.get(fn_name)
    if fn is None or not callable(fn):
        for i, tc in enumerate(test_cases):
            failures.append(f"case {i}: 函数 {fn_name} 未找到")
        return 0, len(test_cases), failures

    passed = 0
    for i, tc in enumerate(test_cases):
        try:
            if tc.expected_raises:
                try:
                    fn(*tc.inputs)
                    failures.append(
                        f"case {i} {tc.description}: 期望抛 {tc.expected_raises} 但未抛"
                    )
                    continue
                except Exception as e:
                    if type(e).__name__ == tc.expected_raises:
                        passed += 1
                    else:
                        failures.append(
                            f"case {i} {tc.description}: 期望 {tc.expected_raises}, "
                            f"实际 {type(e).__name__}: {e}"
                        )
                    continue
            result = fn(*tc.inputs)
            if result == tc.expected and type(result) == type(tc.expected):
                passed += 1
            else:
                failures.append(
                    f"case {i} {tc.description}: input={tc.inputs} "
                    f"期望 {tc.expected!r}({type(tc.expected).__name__}), "
                    f"实际 {result!r}({type(result).__name__})"
                )
        except Exception as e:
            failures.append(
                f"case {i} {tc.description}: 未预期异常 {type(e).__name__}: {e}"
            )
    return passed, len(test_cases), failures


def _heuristic_test_suite(fn_name: str, params: str) -> List[TestCase]:
    """
    无 LLM 时的启发式 fallback: 解析参数名, 生成基本数值用例
    只对算术类函数有效; 非算术返回空列表 (调用方需自行处理)
    """
    # 提取参数名: (a, b) -> ['a', 'b']
    p = params.strip()
    if not (p.startswith("(") and p.endswith(")")):
        return []
    p = p[1:-1].strip()
    if not p:
        return []
    param_names = [x.strip().split(":")[0].split("=")[0].strip() for x in p.split(",")]
    if not all(name.isidentifier() for name in param_names):
        return []
    if len(param_names) != 2:
        return []

    a, b = param_names
    cases: List[TestCase] = []
    if fn_name == "add":
        cases = [
            TestCase((2, 3), 5, description="add 正数"),
            TestCase((-1, 1), 0, description="add 负数"),
            TestCase((0, 0), 0, description="add 零"),
        ]
    elif fn_name == "sub":
        cases = [
            TestCase((5, 3), 2, description="sub 正数"),
            TestCase((0, 5), -5, description="sub 负结果"),
            TestCase((2, 2), 0, description="sub 相等"),
        ]
    elif fn_name == "mul":
        cases = [
            TestCase((2, 3), 6, description="mul 正数"),
            TestCase((-2, 3), -6, description="mul 负数"),
            TestCase((0, 5), 0, description="mul 零"),
            TestCase((2, 1), 2, description="mul 单元"),
        ]
    elif fn_name == "div":
        cases = [
            TestCase((6, 3), 2, description="div 整除"),
            TestCase((5, 2), 2.5, description="div 非整除"),
            TestCase((1, 0), None, expected_raises="ZeroDivisionError",
                     description="div 零除"),
        ]
    return cases


def generate_test_suite(
    fn_name: str,
    params: str,
    prompt: str,
    sample_code: str,
    llm_generator: Optional[GeneratorFn] = None,
) -> List[TestCase]:
    """
    生成一个函数的 IO 测试套件

    Args:
      fn_name:     函数名
      params:      参数字符串 (e.g. "(a, b)")
      prompt:      原 prompt (LLM 据此推断语义)
      sample_code: 一份样例实现 (LLM 据此推断具体行为)
      llm_generator: 可选 LLM; None 时走启发式

    Returns: List[TestCase]; 可能为空 (无法推断时)
    """
    # 无 LLM 时直接走启发式
    if llm_generator is None:
        return _heuristic_test_suite(fn_name, params)

    # 用 LLM 生成 pytest 风格 IO 用例
    instruct = (
        f"为以下 Python 函数生成 5 个测试用例, 只输出 JSON 数组, 不要 markdown 围栏.\n"
        f"函数名: {fn_name}\n"
        f"参数: {params}\n"
        f"原始需求: {prompt}\n"
        f"样例实现:\n```python\n{sample_code}\n```\n"
        f"JSON schema: [{{\"inputs\": [...], \"expected\": ..., "
        f"\"expected_raises\": null 或 \"ZeroDivisionError\", \"description\": \"...\"}}]\n"
        f"只输出 JSON 数组, 不要其他文字."
    )
    try:
        raw = llm_generator(instruct, seed=0)
    except Exception:
        return _heuristic_test_suite(fn_name, params)

    # 提取首个 JSON 数组
    raw = raw.strip()
    # 兼容 ```json ... ``` 围栏
    if raw.startswith("```"):
        raw = raw.split("```", 2)
        raw = raw[1] if len(raw) >= 2 else ""
        if raw.startswith("json"):
            raw = raw[4:]
        raw = raw.strip()
    end = raw.rfind("]")
    start = raw.find("[")
    if start == -1 or end == -1 or end <= start:
        return _heuristic_test_suite(fn_name, params)
    raw_json = raw[start:end + 1]

    try:
        cases_raw = json.loads(raw_json)
    except Exception:
        return _heuristic_test_suite(fn_name, params)

    cases: List[TestCase] = []
    for item in cases_raw:
        if not isinstance(item, dict):
            continue
        inputs = item.get("inputs", [])
        if not isinstance(inputs, list):
            continue
        cases.append(TestCase(
            inputs=tuple(inputs),
            expected=item.get("expected"),
            expected_raises=item.get("expected_raises"),
            description=str(item.get("description", "")),
        ))
    return cases


def _check_variants_io_equivalent(
    fn_signature: str,
    fn_name: str,
    variants: List[FunctionVariant],
    test_cases: List[TestCase],
) -> List[FunctionVariant]:
    """
    给定一个函数的多个变体 + 测试套件, 跑测试并回填 io_equivalent

    规则:
      - 测试套件为空 -> 全部 io_equivalent=None (无法判定)
      - 任一变体全过 -> io_equivalent=True 标到全过的变体上
      - 全过的变体和不全过的变体并存 -> 不全过的标 False
      - 全部不全过 -> 全部 False (无法判定等价, 都可疑)
    """
    import textwrap

    if not test_cases or not variants:
        return variants

    results: List[Tuple[FunctionVariant, Tuple[int, int]]] = []
    for v in variants:
        # body_text 来自 tree-sitter block 节点, 缩进不一致 (第一行可能无缩进,
        # 后续行带原始缩进); 按行 strip 去前导空格再统一 indent 4 空格
        lines = [ln.strip() for ln in v.body_text.splitlines() if ln.strip()]
        body_norm = "\n".join(lines)
        body_indented = textwrap.indent(body_norm, "    ")
        fn_code = f"def {fn_signature}:\n{body_indented}"
        passed, total, _ = run_function_test(fn_code, fn_name, test_cases)
        results.append((v, (passed, total)))

    # 全过 / 不全过分组
    all_pass_variants = [v for v, (p, t) in results if t > 0 and p == t]
    any_pass_exists = len(all_pass_variants) > 0

    out: List[FunctionVariant] = []
    for v, (p, t) in results:
        if t == 0:
            # 测试套件跑不动 (e.g. exec 失败) -> None
            v.io_equivalent = None
        elif p == t:
            # 全过 -> 等价
            v.io_equivalent = True
        else:
            # 不全过 -> 有全过变体则 False (真 bug), 否则 None (无法判定)
            v.io_equivalent = False if any_pass_exists else None
        out.append(v)
    return out


def _check_variants_invariants(
    fn_signature: str,
    fn_name: str,
    variants: List[FunctionVariant],
    invariant_checker: Callable[[str, str], List[Tuple[str, bool]]],
    full_code: str = "",
) -> List[FunctionVariant]:
    """
    对非确定性函数 (用 random/async 的), 精确 IO 等价不适用,
    改为跑不变量检查 (property-based testing).

    invariant_checker(full_code, fn_name) -> [(invariant_name, passed), ...]
      - full_code: 完整代码 (含 import + 函数定义), 可直接 exec
      - fn_name: 函数名
      - 返回: 每个不变量的 (名称, 是否通过)

    规则:
      - 所有不变量通过 -> invariants_pass=True (语义正确)
      - 任一不变量失败 -> invariants_pass=False (违反不变量, 可能是 bug)
    """
    if not variants:
        return variants

    for v in variants:
        try:
            v.invariants = invariant_checker(full_code, fn_name)
        except Exception as e:
            v.invariants = [(f"exec_error:{e}", False)]
    return variants


# ──────────────────────────────────────────────────────────────
# L3 差异三分 (Divergence Triage)
# ──────────────────────────────────────────────────────────────

@dataclass
class Triage:
    """差异三分结果 (行级聚合)"""
    consensus: List[str] = field(default_factory=list)   # 公约数: N/N
    branching: List[Tuple[str, List[int]]] = field(default_factory=list)  # 分叉: k/N
    outliers: List[Tuple[str, int]] = field(default_factory=list)        # 孤岛: 1/N

    @property
    def total(self) -> int:
        return len(self.consensus) + len(self.branching) + len(self.outliers)


def triage_universes(universes: List[Universe]) -> Triage:
    """
    对 N 个宇宙做行级差异三分

    规则:
      - 行出现在所有 N 个宇宙 -> 公约数 (必然骨架)
      - 行出现在 k 个宇宙 (1 < k < N) -> 分叉 (实现选项)
      - 行只出现在 1 个宇宙 -> 孤岛 (异常点)
    """
    n = len(universes)
    if n == 0:
        return Triage()

    # 行内容 -> 出现在哪些宇宙 id
    line_to_universes: dict[str, set] = {}
    for u in universes:
        seen_in_this_u: set[str] = set()  # 同一宇宙内重复行只计一次
        for raw_line in u.code.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if line in seen_in_this_u:
                continue
            seen_in_this_u.add(line)
            line_to_universes.setdefault(line, set()).add(u.id)

    triage = Triage()
    # 按"出现宇宙数"降序排, 公约数稳定在前
    items = sorted(
        line_to_universes.items(),
        key=lambda kv: (-len(kv[1]), kv[0]),
    )
    for line, uids in items:
        count = len(uids)
        if count == n:
            triage.consensus.append(line)
        elif count == 1:
            triage.outliers.append((line, next(iter(uids))))
        else:
            triage.branching.append((line, sorted(uids)))
    return triage


# ──────────────────────────────────────────────────────────────
# L3* AST 函数级三分 (修复行级聚合误判)
# ──────────────────────────────────────────────────────────────
#
# 行级聚合会把"同一函数的多种写法"拆成孤岛行 (e.g. U2 的
# `result = a * b` + `return result` 被当作两条孤岛行, 而非
# 与其他宇宙的 `return a * b` 同属一个分叉).
#
# AST 模式按函数签名对齐: 同名同参函数视为同一函数, body
# 结构签名相同的视为同变体, 不同签名视为不同变体.
# ──────────────────────────────────────────────────────────────


@dataclass
class FunctionDef:
    """单个函数定义 (从一个宇宙的代码中提取)"""
    name: str
    params: str
    body_text: str
    body_signature: Tuple[str, ...]  # AST 节点类型序列

    @property
    def signature(self) -> str:
        return f"{self.name}{self.params}"


@dataclass
class FunctionVariant:
    """同一函数的一个 body 变体"""
    body_signature: Tuple[str, ...]
    body_text: str
    universes: List[int]  # 这个变体出现在哪些宇宙 id
    io_equivalent: Optional[bool] = None  # 是否与其他变体 IO 等价 (None=未测)
    # 属性测试: 不变量检查结果 [(name, passed), ...] (None=未跑)
    # 用于非确定性函数 (如 point_mutation 用 random), 精确 IO 等价不适用,
    # 改为验证不变量 (原输入不被修改/输出类型合法/边界条件满足)
    invariants: Optional[List[Tuple[str, bool]]] = None

    @property
    def invariants_pass(self) -> Optional[bool]:
        """所有不变量是否都通过 (None=未跑)"""
        if self.invariants is None:
            return None
        return all(p for _, p in self.invariants)


@dataclass
class FunctionTriage:
    """AST 函数级三分结果

    consensus: 所有宇宙都实现且 body 结构一致 -> 必然骨架
    branching: 出现 ≥2 个宇宙但 (body 多变体 或 出现 < N) -> 实现选项
    outliers:  只在 1 个宇宙出现 -> 异常函数
    """
    consensus: List[str] = field(default_factory=list)
    branching: List[Tuple[str, List[FunctionVariant]]] = field(default_factory=list)
    outliers: List[Tuple[str, int]] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.consensus) + len(self.branching) + len(self.outliers)


def _walk_signature(node) -> List[str]:
    """递归收集 AST 节点类型序列 (用作结构签名)"""
    sig: List[str] = [node.type]
    for child in node.children:
        sig.extend(_walk_signature(child))
    return sig


def parse_functions(code: str) -> List[FunctionDef]:
    """
    用 tree-sitter 解析代码, 提取顶层 function_definition

    Returns: [] if tree-sitter 不可用或代码无法解析
    """
    if not _TS_AVAILABLE or _PARSER is None:
        raise ImportError(
            "AST 模式需要 tree-sitter; 请运行 pip install tree-sitter tree-sitter-python"
        )
    tree = _PARSER.parse(code.encode("utf-8"))
    funcs: List[FunctionDef] = []
    for node in tree.root_node.children:
        if node.type != "function_definition":
            continue
        name_node = node.child_by_field_name("name")
        params_node = node.child_by_field_name("parameters")
        body_node = node.child_by_field_name("body")
        if not (name_node and body_node):
            continue
        name = name_node.text.decode("utf-8")
        params = params_node.text.decode("utf-8") if params_node else "()"
        body_text = body_node.text.decode("utf-8")
        body_sig = tuple(_walk_signature(body_node))
        funcs.append(FunctionDef(name, params, body_text, body_sig))
    return funcs


def triage_universes_ast(
    universes: List[Universe],
    test_generator: Optional[Callable[[str, str, str, str], List[TestCase]]] = None,
    prompt: str = "",
    invariant_checker: Optional[Callable[[str, str], List[Tuple[str, bool]]]] = None,
) -> FunctionTriage:
    """
    对 N 个宇宙做 AST 函数级差异三分

    规则:
      - 函数出现在所有 N 个宇宙 且 body 只一个变体 -> 公约数
      - 函数出现在 ≥2 个宇宙 但 body 多变体 或 出现 < N -> 分叉
      - 函数只出现在 1 个宇宙 -> 孤岛

    Args:
      universes:         宇宙列表
      test_generator:    可选 (fn_name, params, prompt, sample_code) -> List[TestCase]
                         提供时, 对 branching 中的每个变体跑 IO 测试, 回填 io_equivalent
      prompt:            原 prompt, 传给 test_generator 做语义推断
      invariant_checker: 可选 (fn_code, fn_name) -> [(name, passed), ...]
                         提供时, 对 branching 中的每个变体跑不变量检查 (属性测试),
                         回填 invariants; 用于非确定性函数 (用 random/async)
    """
    n = len(universes)
    if n == 0:
        return FunctionTriage()

    # 函数签名 -> [(uid, FunctionDef), ...]
    funcs_by_sig: dict[str, list] = {}
    for u in universes:
        try:
            funcs = parse_functions(u.code)
        except Exception:
            funcs = []
        for fn in funcs:
            funcs_by_sig.setdefault(fn.signature, []).append((u.id, fn))

    consensus: List[str] = []
    branching: List[Tuple[str, List[FunctionVariant]]] = []
    outliers: List[Tuple[str, int]] = []

    for sig, instances in funcs_by_sig.items():
        uids = [uid for uid, _ in instances]
        unique_uids = set(uids)
        unique_count = len(unique_uids)

        if unique_count == 1:
            outliers.append((sig, next(iter(unique_uids))))
            continue

        # 按 body_signature 分组变体
        variants_by_sig: dict[tuple, list] = {}
        for uid, fn in instances:
            variants_by_sig.setdefault(fn.body_signature, []).append((uid, fn))

        if unique_count == n and len(variants_by_sig) == 1:
            # 全 N 宇宙都有 + body 单一变体 -> 公约数
            consensus.append(sig)
        else:
            # 分叉: 多变体 或 出现 < N
            variants: List[FunctionVariant] = []
            for bs, items in variants_by_sig.items():
                v_uids = sorted({uid for uid, _ in items})
                body_text = items[0][1].body_text
                variants.append(FunctionVariant(
                    body_signature=bs,
                    body_text=body_text,
                    universes=v_uids,
                ))
            # 按变体大小降序 (主流变体在前)
            variants.sort(key=lambda v: -len(v.universes))
            # sig 形如 "mul(a, b)"; 拆出 fn_name
            fn_name = sig.split("(", 1)[0].strip()
            # L2.5 语义层: 如果提供了 test_generator, 对 branching 跑 IO 测试,
            # 回填 io_equivalent; 区分"风格差异 (可接受)" vs "真 bug"
            if test_generator is not None and variants:
                params = sig[len(fn_name):].strip()
                if not params.startswith("("):
                    params = "()"
                sample = variants[0].body_text
                try:
                    test_cases = test_generator(fn_name, params, prompt, sample)
                except Exception:
                    test_cases = []
                variants = _check_variants_io_equivalent(
                    sig, fn_name, variants, test_cases
                )
            # L2.5 扩展: 不变量检查 (属性测试) — 非确定性函数专用
            if invariant_checker is not None and variants:
                # 用包含该变体的第一个宇宙的完整代码 (含 import)
                first_uid = variants[0].universes[0]
                full_code = ""
                for u in universes:
                    if u.id == first_uid:
                        full_code = u.code
                        break
                # 每个变体用其自己所属宇宙的代码 (确保测试对应变体)
                for v in variants:
                    v_uid = v.universes[0]
                    v_code = ""
                    for u in universes:
                        if u.id == v_uid:
                            v_code = u.code
                            break
                    try:
                        v.invariants = invariant_checker(v_code, fn_name)
                    except Exception as e:
                        v.invariants = [(f"exec_error:{e}", False)]
            branching.append((sig, variants))

    consensus.sort()
    branching.sort(key=lambda x: -len(x[1]))
    outliers.sort(key=lambda x: x[0])
    return FunctionTriage(consensus, branching, outliers)


# ──────────────────────────────────────────────────────────────
# L4 QA 信号 (QA Signal Extraction)
# ──────────────────────────────────────────────────────────────

@dataclass
class QASignal:
    """三类差异 -> 三级 QA 动作"""
    consensus_action: str
    branching_action: str
    outlier_action: str
    consensus_count: int
    branching_count: int
    outlier_count: int


def extract_qa_signal(triage: Triage) -> QASignal:
    """
    强信号 -> 必查正确性   (公约数)
    中信号 -> 验证等价性   (分叉)
    弱信号 -> 强制 review (孤岛, 必查)
    """
    return QASignal(
        consensus_action="必查正确性 (强信号)",
        branching_action="验证等价性 (中信号)",
        outlier_action="强制 review (弱信号, 必查)",
        consensus_count=len(triage.consensus),
        branching_count=len(triage.branching),
        outlier_count=len(triage.outliers),
    )


# ──────────────────────────────────────────────────────────────
# L5 度量 (Metrics)
# ──────────────────────────────────────────────────────────────

@dataclass
class Metrics:
    """
    核心度量:
      UCS              = 公约数 / 总量         (越高越收敛)
      robustness       = 1 - 孤岛率            (越高越鲁棒)
      convergence      = 1 - 分叉率            (越高越一致)

    扩展度量 (诊断维度):
      outlier_severity = 孤岛率                (孤岛占比, 0~1, 越高越危险)
      divergence_density = 平均分叉变体数       (实现分歧激烈程度, >=1)
                           1 = 分叉函数都只有 1 个变体 (出现宇宙数差异)
                           >1 = 存在多变体分叉 (prompt 约束不足)
    """
    ucs: float
    robustness: float
    convergence: float
    n: int
    total_lines: int
    outlier_severity: float = 0.0
    divergence_density: float = 0.0

    @property
    def converged(self) -> bool:
        """铁律 3: UCS >= 阈值才算分布收敛.

        阈值由 load_thresholds() 提供, 默认 0.6, 经验校准后可替换.
        """
        thr = load_thresholds().get("ucs_converged", 0.6)
        return self.ucs >= thr

    @property
    def solution_space(self) -> str:
        """解空间分类 (实证修正): 区分「多解型」vs「歧义型」低 UCS.

        阈值 τ 由 load_thresholds() 提供 (默认 0.6, 实证校准 0.5).

        返回值:
          "unique"     — 唯一解 (UCS>=τ, 解空间收敛)
          "multi"      — 多解型 (UCS<τ 但孤岛=0 且分歧密度>1,
                         prompt 清晰但问题有多解, 分叉应走 IO 等价)
          "ambiguous"  — 歧义型 (UCS<τ 且孤岛多, prompt 本身有问题)
          "degenerate" — 退化型 (UCS>=0.95 无孤岛, 警惕 F1)
        """
        return classify_solution_space(self)

    def __repr__(self) -> str:
        flag = "" if self.converged else " [未收敛]"
        return (
            f"Metrics(UCS={self.ucs:.3f}, "
            f"鲁棒={self.robustness:.3f}, "
            f"收敛={self.convergence:.3f}, "
            f"孤岛严重={self.outlier_severity:.3f}, "
            f"分歧密度={self.divergence_density:.2f}, "
            f"N={self.n}{flag})"
        )


def compute_metrics(triage, n: int) -> Metrics:
    """
    行级: 用 token 加权 (word 数)
    函数级: 用计数 (一个函数 = 一个数据点)
    """
    total = triage.total
    if total == 0:
        return Metrics(0.0, 0.0, 0.0, n, 0)

    is_ast = isinstance(triage, FunctionTriage)
    if is_ast:
        # 函数级: 用计数 (函数签名 token 数太少, 会让 metrics 失真)
        cons = len(triage.consensus)
        branch = len(triage.branching)
        outlier = len(triage.outliers)
        denom = total
    else:
        # 行级: 用 token 加权
        cons_tokens = sum(len(l.split()) for l in triage.consensus)
        branch_tokens = sum(len(line.split()) for line, _ in triage.branching)
        outlier_tokens = sum(len(line.split()) for line, _ in triage.outliers)
        denom = cons_tokens + branch_tokens + outlier_tokens
        if denom == 0:
            return Metrics(0.0, 0.0, 0.0, n, total)
        cons = cons_tokens
        branch = branch_tokens
        outlier = outlier_tokens

    ucs = cons / denom
    outlier_rate = outlier / denom
    branching_rate = branch / denom

    # 扩展度量: 分歧密度 = 平均分叉变体数
    if is_ast:
        # AST: branching 是 List[Tuple[str, List[FunctionVariant]]]
        variant_counts = [len(vs) for _, vs in triage.branching]
    else:
        # 行级: branching 是 List[Tuple[str, List[int]]] (行, 出现宇宙列表)
        variant_counts = [len(uids) for _, uids in triage.branching]
    divergence_density = (
        sum(variant_counts) / len(variant_counts) if variant_counts else 0.0
    )

    return Metrics(
        ucs=ucs,
        robustness=1.0 - outlier_rate,
        convergence=1.0 - branching_rate,
        n=n,
        total_lines=total,
        outlier_severity=outlier_rate,
        divergence_density=divergence_density,
    )


def metrics_bars(metrics: Metrics, width: int = 40) -> str:
    """
    L5 可视化: 用 ASCII 水平条形图展示 5 个度量, 一眼看出短板.

    归一化:
      - UCS / robustness / convergence: 直接用值 (0~1)
      - outlier_severity: 越低越好, 条形反向 (显示为 1 - severity)
      - divergence_density: 1~N, 用 min(density/3, 1.0) 归一化
    """
    rows = [
        ("UCS", metrics.ucs, metrics.ucs),
        ("鲁棒性", metrics.robustness, metrics.robustness),
        ("收敛度", metrics.convergence, metrics.convergence),
        ("孤岛安全(1-严重度)", 1.0 - metrics.outlier_severity,
         1.0 - metrics.outlier_severity),
        ("分歧密度", min(metrics.divergence_density / 3.0, 1.0),
         metrics.divergence_density),
    ]
    lines: List[str] = ["## L5 度量可视化", ""]
    for name, bar_val, real_val in rows:
        filled = int(round(bar_val * width))
        bar = "█" * filled + "░" * (width - filled)
        lines.append(f"{name:<16} |{bar}| {real_val:.3f}")
    return "\n".join(lines)


# ──────────────────────────────────────────────────────────────
# L6 反向 Prompt 优化 (Reverse Prompt Optimization)
# ──────────────────────────────────────────────────────────────
#
# 铁律 3: UCS < 阈值时停审回头改 prompt. 但"怎么改"靠人工.
# 阈值由 load_thresholds() 提供 (默认 0.6, 52-prompt 实证校准后 0.5).
# L6 自动分析 triage 模式, 给出可执行的 prompt 改进建议:
#
#   1. 孤岛函数 (outliers)      -> prompt 漏掉/多写了函数, 建议显式要求或排除
#   2. 分叉变体多 (branching)   -> prompt 没约束实现细节, 建议加写法约束
#   3. 函数缺失 (出现在 < N)   -> prompt 没明确函数清单, 建议列出必须实现的函数
#   4. IO 不等价 (真 bug)       -> 该函数有真分歧, prompt 需更精确描述行为
#
# 触发条件: metrics.converged == False (UCS < 阈值)
# 注意: 若 solution_space == "multi", 不应触发 L6 (多解非歧义, 应走 IO 等价).
# ──────────────────────────────────────────────────────────────


def classify_solution_space(metrics: "Metrics") -> str:
    """解空间分类 (实证修正, 阶梯 1 发现).

    实证发现 UCS<阈值有两种截然不同的原因:
      1. 歧义型: 孤岛多 + 分歧密度低 -> prompt 本身有问题, 需重写
      2. 多解型: 孤岛=0 + 分歧密度高 -> prompt 清晰但问题有多解,
         分叉是"不同正确实现"而非"约束不足", 应走 L2.5 IO 等价测试

    判定逻辑 (阈值经 load_thresholds() 动态加载, 默认 0.6, 实证 0.5):
      UCS >= 0.95 + 无孤岛  -> "degenerate" (警惕 F1)
      UCS >= 阈值            -> "unique" (解空间收敛)
      UCS < 阈值 + 孤岛多      -> "ambiguous" (prompt 有问题)
      UCS < 阈值 + 孤岛=0 + 分歧密度>1 -> "multi" (多解, 走 IO 等价)
      UCS < 阈值 + 其他        -> "ambiguous" (兜底归歧义)
    """
    thr = load_thresholds().get("ucs_converged", 0.6)
    if metrics.ucs >= 0.95 and metrics.outlier_severity == 0:
        return "degenerate"
    if metrics.ucs >= thr:
        return "unique"
    # UCS < thr
    if metrics.outlier_severity > 0.1:
        # 有孤岛 -> 歧义型
        return "ambiguous"
    # 无孤岛但 UCS 低
    if metrics.divergence_density > 1.0 and metrics.convergence < 1.0:
        # 有分叉 (convergence<1 说明有 branching) 且分歧密度高 -> 多解
        return "multi"
    if metrics.convergence < 1.0 and metrics.divergence_density > 0:
        # 有分叉但分歧密度不高, 仍可能是多解
        return "multi"
    # 兜底: UCS 低 + 无孤岛 + 无分叉 -> 异常状态, 归歧义
    return "ambiguous"


def diagnose(report: "PWPReport") -> List[str]:
    """
    L6 诊断层: 基于第 11 节「Prompt 质量诊断映射」,
    从 report 的度量 + triage 反推 prompt 可能存在的问题.

    与 suggest_prompt_improvements 的区别:
      - suggest_... : 给"怎么改"的具体建议 (仅 UCS<0.6 时触发)
      - diagnose    : 给"哪里有问题"的诊断结论 (任何 UCS 都跑)

    Returns: List[str]; 每条是一个 "症状 -> 推断" 的结论.
            空 list 表示无明显问题.
    """
    findings: List[str] = []
    m = report.metrics
    triage = report.triage
    space = m.solution_space  # unique/multi/ambiguous/degenerate

    # 1. 孤岛严重 (歧义型特征)
    if m.outlier_severity > 0.2:
        findings.append(
            f"孤岛严重 (占比 {m.outlier_severity:.0%}) -> "
            "prompt 对「必须包含哪些函数」约束不清, LLM 自行增删"
        )

    # 2. 分歧密度高 —— 实证修正: 区分多解型 vs 歧义型
    if m.divergence_density > 2:
        if space == "multi":
            # 多解型: 分歧是"不同正确实现", 不是"约束不足"
            findings.append(
                f"分歧密度高 (平均 {m.divergence_density:.1f} 变体/分叉) -> "
                "解空间分类=多解型: prompt 清晰但问题本身有多解, "
                "分叉是不同正确实现而非约束不足, "
                "建议跑 L2.5 IO 等价测试区分风格差异 vs 真 bug"
            )
        else:
            findings.append(
                f"分歧密度高 (平均 {m.divergence_density:.1f} 变体/分叉) -> "
                "prompt 对「函数行为/实现」约束不足, LLM 自由发挥"
            )
    elif m.divergence_density == 1.0 and len(triage.branching) > 0:
        findings.append(
            "分叉均为函数缺失型 (变体数=1) -> "
            "prompt 对函数清单约束不足, 建议明确列出必须实现的函数"
        )

    # 3. IO 不等价分叉 (真歧义)
    io_unequal = 0
    if isinstance(triage, FunctionTriage):
        for _, variants in triage.branching:
            for v in variants:
                if v.io_equivalent is False:
                    io_unequal += 1
                    break
    if io_unequal > 0:
        findings.append(
            f"{io_unequal} 个函数存在 IO 不等价分叉 -> "
            "prompt 有歧义, 不同解读导致行为分歧, 需消歧"
        )

    # 4. UCS 极低 —— 实证修正: 按解空间分类给不同结论
    if m.ucs < 0.3:
        if space == "ambiguous":
            findings.append(
                "UCS 极低且解空间=歧义型 -> prompt 过宽/模糊, 建议重写而非微调"
            )
        elif space == "multi":
            findings.append(
                "UCS 极低且解空间=多解型 -> 问题有多个正确解, "
                "UCS 低不反映 prompt 质量差, 建议走 IO 等价测试验证分叉正确性"
            )

    # 5. UCS 极高 (警惕 F1)
    if m.ucs >= 0.95 and len(triage.outliers) == 0:
        findings.append(
            "UCS>=0.95 且无孤岛 -> 警惕 F1 模型退化 (全宇宙犯同一个错), "
            "也可能是 prompt 过窄牺牲了灵活性, 需人工验证公约数正确性"
        )

    # 6. 未收敛兜底 —— 实证修正: 按分类给更精准的兜底
    if not m.converged and not findings:
        if space == "multi":
            findings.append(
                f"UCS={m.ucs:.3f} 解空间=多解型 -> "
                "prompt 清晰但问题有多解, 分叉可能都是正确的, "
                "建议跑 IO 等价测试而非加约束"
            )
        elif space == "ambiguous":
            findings.append(
                f"UCS={m.ucs:.3f} 解空间=歧义型 -> "
                "prompt 有歧义, 建议查看分叉明细确定具体约束缺口"
            )
        else:
            findings.append(
                f"UCS={m.ucs:.3f} 未收敛但无明显症状 -> "
                "建议查看分叉明细确定具体约束缺口"
            )

    return findings


def suggest_prompt_improvements(
    triage: Triage,
    metrics: Metrics,
    prompt: str,
) -> List[str]:
    """
    分析 triage 模式, 给出 prompt 改进建议

    Returns: List[str]; 空 list 表示无需改进 (已收敛)
    """
    suggestions: List[str] = []

    # 已收敛: 不需要改进
    if metrics.converged:
        return suggestions

    is_ast = isinstance(triage, FunctionTriage)
    space = metrics.solution_space  # 实证修正: 多解型走不同路径

    if is_ast:
        # ─── 模式 1: 孤岛函数 (有的宇宙写了, 别的没写) ───
        if triage.outliers:
            outlier_sigs = [sig for sig, _ in triage.outliers]
            # 提取函数名
            fn_names = [s.split("(", 1)[0].strip() for s in outlier_sigs]
            suggestions.append(
                f"**孤岛函数 (在 {len(triage.outliers)}/{metrics.n} 宇宙独有):** "
                f"prompt 没明确要求/排除这些函数: {', '.join(fn_names)}. "
                f"建议在 prompt 显式列出必须实现的函数清单, 或显式排除不需要的."
            )

        # ─── 模式 2: 分叉变体多 (实现细节不一致) ───
        # 实证修正: 多解型 prompt 不建议加约束, 而是走 IO 等价
        if triage.branching:
            multi_variant = [
                (sig, variants)
                for sig, variants in triage.branching
                if len(variants) > 1
            ]
            if multi_variant:
                fn_list = ", ".join(sig.split("(", 1)[0].strip()
                                     for sig, _ in multi_variant[:5])
                if space == "multi":
                    # 多解型: 分叉是不同正确实现, 不加约束, 走 IO 等价
                    suggestions.append(
                        f"**分叉变体多 (解空间=多解型):** {len(multi_variant)} 个函数有多种写法: "
                        f"{fn_list}. 这是问题本身有多解, 不是 prompt 约束不足. "
                        f"**不建议加约束强制统一写法** (会牺牲正确解的多样性). "
                        f"建议跑 L2.5 IO 等价测试 (`run(..., test_generator=generate_test_suite)`), "
                        f"区分「风格差异 (IO 等价, 可接受)」vs「真 bug (IO 不等价, 需消歧)」."
                    )
                else:
                    # 歧义型或其他: 原逻辑, 建议加约束
                    suggestions.append(
                        f"**分叉变体多 (实现细节不一致):** {len(multi_variant)} 个函数有多种写法: "
                        f"{fn_list}. 建议在 prompt 加约束, 如 \"mul 用单行 `return a * b`, "
                        f"不要用临时变量\". 减少实现自由度, 让多宇宙收敛到同一写法."
                    )

        # ─── 模式 3: 函数缺失 (出现在 < N 个宇宙) ───
        # branching 里"出现 < N"的也算缺失
        missing_in_branch: List[str] = []
        for sig, variants in triage.branching:
            total_u = sum(len(v.universes) for v in variants)
            if total_u < metrics.n:
                fn_name = sig.split("(", 1)[0].strip()
                missing_in_branch.append(
                    f"{fn_name} (仅 {total_u}/{metrics.n} 宇宙实现)"
                )
        if missing_in_branch:
            suggestions.append(
                f"**函数缺失 (部分宇宙没实现):** {', '.join(missing_in_branch[:5])}. "
                f"建议在 prompt 开头明确列出函数清单, 如 "
                f"\"必须实现: add, sub, mul, div 四个函数, 缺一不可\"."
            )

        # ─── 模式 4: IO 不等价 (真 bug) ───
        io_bugs: List[str] = []
        for sig, variants in triage.branching:
            for v in variants:
                if v.io_equivalent is False:
                    fn_name = sig.split("(", 1)[0].strip()
                    io_bugs.append(fn_name)
                    break
        if io_bugs:
            suggestions.append(
                f"**IO 不等价 (真 bug, 必须 review):** {', '.join(io_bugs[:5])} "
                f"的多个变体行为不一致 (跑同一组测试, 部分失败). "
                f"prompt 需要更精确描述该函数的期望行为 (输入/输出/边界), "
                f"如 \"div 在 b==0 时必须抛 ZeroDivisionError, 不能返回 None\"."
            )
    else:
        # 行级: 只能从 outliers/branching 行内容做粗粒度建议
        if triage.outliers:
            sample_lines = [line for line, _ in triage.outliers[:3]]
            suggestions.append(
                f"**孤岛行 (只在 1 个宇宙出现):** "
                f"如 `{sample_lines[0][:60]}` 等 {len(triage.outliers)} 行. "
                f"这些是异常实现, 建议在 prompt 显式约束排除或要求."
            )
        if triage.branching:
            suggestions.append(
                f"**分叉行多:** {len(triage.branching)} 行有多种写法. "
                f"建议在 prompt 加约束减少实现自由度 (e.g. 指定变量名 / 写法 / 返回值类型)."
            )

    if not suggestions:
        suggestions.append(
            "**UCS 未收敛但无明显模式:** 建议增加 N (宇宙数) 到 10, "
            "或检查 prompt 是否过于宽泛导致每次生成都很不一样."
        )
    return suggestions


def auto_rewrite_prompt(
    suggestions: List[str],
    prompt: str,
    llm_generator: Optional[GeneratorFn] = None,
) -> Optional[str]:
    """
    用 LLM 根据 suggestions 改写 prompt (可选)

    无 LLM 时返回 None, 调用方自己根据 suggestions 手动改
    """
    if llm_generator is None or not suggestions:
        return None
    instruct = (
        f"根据以下改进建议, 改写原始 prompt 让它更精确、更能收敛到一致实现.\n"
        f"只输出改写后的 prompt, 不要其他文字.\n\n"
        f"原始 prompt:\n{prompt}\n\n"
        f"改进建议:\n" + "\n".join(f"- {s}" for s in suggestions)
    )
    try:
        return llm_generator(instruct, seed=42).strip()
    except Exception:
        return None


# ──────────────────────────────────────────────────────────────
# L8 最优决策 (Optimal Decision)  —— 决策论落地层 (第 16 节)
# 基于 D1-D5 定理与决策树, 给定 PWPReport 输出代价最优的下一步动作.
# 决策空间 A = {release, review, rewrite_prompt, run_io_test,
#               verify_degenerate, increase_N}
# 代价函数 Cost(a, σ): release=0/∞, review=c_r, rewrite=c_w>c_r,
#                       run_io_test=c_io, verify_degenerate=c_v, increase_N=c_N
# ──────────────────────────────────────────────────────────────

# 默认代价常数 (相对值, 仅用于排序; 真实代价因团队/模型而异)
DEFAULT_COSTS = {
    "release": 0.0,             # 放行: 无代价 (前提 σ=unique 且无异常)
    "review": 1.0,              # 人工审查孤岛+分叉
    "rewrite_prompt": 2.0,      # 重写 prompt (比审查更贵)
    "run_io_test": 1.5,         # 跑 IO 等价测试 (API 成本)
    "verify_degenerate": 3.0,   # 人工验证是否 F1 (最贵)
    "increase_N": 1.2,          # 多跑宇宙的采样成本
}


@dataclass
class Decision:
    """最优决策结果 (第 16 节 D1-D5)

    Attributes:
        action:     最优动作 (release/review/rewrite_prompt/run_io_test/
                    verify_degenerate/increase_N)
        theorem:    触发的定理编号 (D1-D5)
        sigma:      解空间分类 (unique/multi/ambiguous/degenerate)
        reason:     人类可读的决策理由
        cost:       该动作的相对代价
        next_steps: 后续可执行的动作建议 (有序)
    """
    action: str
    theorem: str
    sigma: str
    reason: str
    cost: float
    next_steps: List[str] = field(default_factory=list)

    def to_markdown(self) -> str:
        lines = [
            "## L8 最优决策 (第 16 节 决策论)",
            "",
            f"- **动作**: `{self.action}`  ({self.theorem})",
            f"- **解空间 σ**: `{self.sigma}`",
            f"- **代价**: {self.cost}",
            f"- **理由**: {self.reason}",
        ]
        if self.next_steps:
            lines.append("- **后续步骤**:")
            for s in self.next_steps:
                lines.append(f"  - {s}")
        return "\n".join(lines)


def _has_outliers(triage) -> bool:
    """是否存在孤岛 (异常函数)"""
    return bool(getattr(triage, "outliers", None))


def _io_branch_status(triage) -> Tuple[bool, bool]:
    """检查分叉的 IO 等价状态.

    Returns: (tested, has_inequivalent)
      - tested: 是否有任一分叉被跑过 IO 测试 (io_equivalent 非 None)
      - has_inequivalent: 是否存在 IO 不等价的分叉
    仅 AST 函数级 triage (FunctionTriage) 的 FunctionVariant 有 io_equivalent;
    行级 triage 无此字段, 返回 (False, False).
    """
    tested = False
    has_inequivalent = False
    branching = getattr(triage, "branching", []) or []
    for entry in branching:
        # AST: (sig, List[FunctionVariant]); 行级: (line, List[uid])
        variants = entry[1] if isinstance(entry, (tuple, list)) and len(entry) > 1 else []
        if not isinstance(variants, list):
            continue
        for v in variants:
            ioeq = getattr(v, "io_equivalent", None)
            if ioeq is not None:
                tested = True
                if ioeq is False:
                    has_inequivalent = True
    return tested, has_inequivalent


def decide(report: "PWPReport", costs: Optional[dict] = None) -> Decision:
    """基于 D1-D5 决策树, 输出代价最优的下一步动作.

    决策树 (第 16.3 节):
      σ=unique?
        ├─ 孤岛=0 ∧ (未测 IO ∨ IO 全等价) → release (D1) [Cost=0]
        └─ 有孤岛 ∨ IO 不等价             → review (D2) [Cost=c_r]
      σ=multi?
        ├─ 未测 IO                         → run_io_test (D3) [Cost=c_io]
        ├─ IO 全等价                       → release (良性多解) [Cost=c_io]
        └─ 有 IO 不等价                    → review (恶性多解) [Cost=c_io+c_r]
      σ=ambiguous → rewrite_prompt (D4) [Cost=c_w]
      σ=degenerate → verify_degenerate (D5) [Cost=c_v]

    Args:
        report: run() 返回的 PWPReport
        costs:  代价常数覆盖 (None 用 DEFAULT_COSTS)

    Returns:
        Decision 对象
    """
    costs = dict(DEFAULT_COSTS) if costs is None else dict(costs)
    sigma = report.metrics.solution_space
    has_out = _has_outliers(report.triage)
    io_tested, has_io_div = _io_branch_status(report.triage)
    io_clean = (not io_tested) or (not has_io_div)

    n = report.metrics.n

    # D4: 歧义型 —— 重写 prompt 比 review 更划算 (无共识可审)
    if sigma == "ambiguous":
        next_steps = [
            "用 L6 suggest_prompt_improvements 取具体建议",
            "auto_rewrite_prompt 后重跑 run()",
        ]
        if n < 10:
            next_steps.append(f"当前 N={n} 偏小, 可考虑 increase_N 提升统计可靠性")
        return Decision(
            action="rewrite_prompt",
            theorem="D4",
            sigma=sigma,
            reason=f"σ=ambiguous (UCS={report.metrics.ucs:.3f} 且有孤岛), "
                   f"prompt 约束不足; review 面对 LLM 各写各的无共识可审, "
                   f"重写 prompt 期望代价更低.",
            cost=costs["rewrite_prompt"],
            next_steps=next_steps,
        )

    # D5: 退化型 —— 警惕 F1 (全宇宙同错), 必须人工验证公约正确性
    if sigma == "degenerate":
        return Decision(
            action="verify_degenerate",
            theorem="D5",
            sigma=sigma,
            reason=f"σ=degenerate (UCS={report.metrics.ucs:.3f}≥0.95 无孤岛), "
                   f"高度一致可能是 prompt 完美, 也可能是 F1 失败模式 "
                   f"(全宇宙同错); 必须人工验证公约数正确性.",
            cost=costs["verify_degenerate"],
            next_steps=[
                "人工审查公约数函数的正确性 (是否满足规约)",
                "若发现 F1, 重写 prompt 并补充反例约束",
            ],
        )

    # D1/D2: 唯一解
    if sigma == "unique":
        if not has_out and io_clean:
            # D1: 唯一解 + 无孤岛 + IO 全等价 → 可放行
            next_steps = [
                "可合入 / 发布; 如需严格保证, 调用 plan_formal_verification() "
                "对公约数做形式化验证 (CT1/CT3).",
            ]
            return Decision(
                action="release",
                theorem="D1",
                sigma=sigma,
                reason=f"σ=unique (UCS={report.metrics.ucs:.3f}≥阈值) 且 "
                       f"孤岛=0 且 IO 全等价; 无异常, 放行代价为 0.",
                cost=costs["release"],
                next_steps=next_steps,
            )
        # D2: 唯一解但有孤岛或 IO 不等价 → 审查异常部分
        detail = []
        if has_out:
            detail.append(f"{len(report.triage.outliers)} 个孤岛")
        if has_io_div:
            detail.append("存在 IO 不等价分叉")
        return Decision(
            action="review",
            theorem="D2",
            sigma=sigma,
            reason=f"σ=unique 但有异常 ({', '.join(detail)}); "
                   f"收敛但有 bug 候选, 需人工审查孤岛与不等价分叉.",
            cost=costs["review"],
            next_steps=[
                "优先审查孤岛 (F2/F3 高风险区)",
                "对 IO 不等价分叉判定哪个变体正确, 修正 prompt 或代码",
            ],
        )

    # D3: 多解型 —— 跑 IO 等价区分良性 (风格) vs 恶性 (bug)
    if sigma == "multi":
        if not io_tested:
            return Decision(
                action="run_io_test",
                theorem="D3",
                sigma=sigma,
                reason=f"σ=multi (UCS={report.metrics.ucs:.3f} 但孤岛=0, "
                       f"分叉是不同实现); 需跑 L2.5 IO 等价测试区分 "
                       f"良性多解 (风格差异) 与恶性多解 (真 bug).",
                cost=costs["run_io_test"],
                next_steps=[
                    "run(..., test_generator=generate_test_suite) 跑 IO 等价",
                    "若 IO 全等价 → release (良性多解, 任选一变体)",
                    "若有 IO 不等价 → review (恶性多解, 消歧)",
                ],
            )
        if not has_io_div:
            # 良性多解
            return Decision(
                action="release",
                theorem="D3",
                sigma=sigma,
                reason=f"σ=multi 且 IO 全等价; 分叉是风格差异, 行为一致, "
                       f"可任选一变体放行.",
                cost=costs["run_io_test"],  # 已付出 IO 测试代价
                next_steps=[
                    "任选一个分叉变体合入; 如需严格保证, "
                    "调用 plan_formal_verification() 做形式化验证 (CT3).",
                ],
            )
        # 恶性多解
        return Decision(
            action="review",
            theorem="D3",
            sigma=sigma,
            reason=f"σ=multi 但存在 IO 不等价分叉; 不同变体行为不同, "
                   f"属真 bug, 需人工消歧.",
            cost=costs["run_io_test"] + costs["review"],
            next_steps=[
                "判定哪个变体符合规约, 修正其他变体或 prompt",
            ],
        )

    # 理论上不会到这里 (sigma 四值穷举), 保险返回 review
    return Decision(
        action="review",
        theorem="D2",
        sigma=sigma,
        reason=f"未知解空间分类 σ={sigma!r}, 保守走 review.",
        cost=costs["review"],
    )


# ──────────────────────────────────────────────────────────────
# L8* N 选择定理 (Sample Size)  —— 第 17 节
# 从 Hoeffding 界推导最少样本量: N_min(ε, δ) = ln(2/δ) / (2ε²)
# 用于 increase_N 决策: 当前 N 不够可靠时, 计算需要多少宇宙.
# ──────────────────────────────────────────────────────────────

def n_min(eps: float = 0.1, delta: float = 0.3) -> int:
    """最少样本量定理 (第 17 节).

    从 Hoeffding 界 P(|p̂-p*| ≥ ε) ≤ 2·exp(-2Nε²) 解出:

        N_min(ε, δ) = ⌈ln(2/δ) / (2ε²)⌉

    Args:
        eps:   容许误差 (UCS 估计值与真实值的最大偏差), 默认 0.1
        delta: 失败概率 (估计超出误差的概率上界), 默认 0.3

    Returns:
        最少宇宙数 N (向上取整)

    常用组合:
        n_min(0.1, 0.3)  = 95   (统计可信)
        n_min(0.15, 0.5) = 31   (中等可靠)
        n_min(0.2, 0.5)  = 17   (快速冒烟+)
        n_min(0.2, 0.8)  = 12   (工程最优下限)

    注意: PWP-QA 默认 N=5 是工程启发式 (δ>0.8), 非统计严格;
    校准阈值 (默认 0.6, 实证 0.5) 补偿统计严格性不足.
    """
    if eps <= 0:
        raise ValueError("eps 必须 > 0")
    if not (0 < delta < 1):
        raise ValueError("delta 必须在 (0, 1) 区间")
    raw = math.log(2.0 / delta) / (2.0 * eps * eps)
    return int(math.ceil(raw))


# ──────────────────────────────────────────────────────────────
# L8** Prompt 质量熵判据 (Entropy-based Quality)  —— 第 18.1 节
# 质量函数 Q(p) = 1 - H(x|p) / H_max
#   H(x|p) = -Σ P(x|p) log P(x|p)   (LLM 输出分布的香农熵)
#   H_max  = log|S(p)|              (均匀分布时的最大熵)
#   |S(p)| = prompt p 的解空间大小 (经 N 次采样的去重输出经验估计)
# 理论 (第 18.1 节): UCS 可视为 Q(p) 的经验估计;
#   Q(p) 给出基于熵的独立视角, UCS 与 Q(p) 偏离时提示分布形态:
#     Q(p) >> UCS: 解空间大但分布不均 (少数解主导, 多数零散)
#     Q(p) ≈ UCS : 分布相对均匀
# 第 18.2 节解空间熵特征:
#     unique/degenerate: H≈0, Q(p)≈1 (unique 是真收敛; degenerate 警惕 F1)
#     multi:  H>0 集中, Q(p) 中等 (几个正确实现各占一部分)
#     ambiguous: H>0 分散, Q(p) 低 (LLM 各写各的, 无主导)
# ──────────────────────────────────────────────────────────────

def _normalize_code(code: str) -> str:
    """归一化代码文本用于去重 (Q(p) 解空间估计).

    剥离空白差异 / 注释, 使语义相同的代码被视为同一个解:
      - 去除纯注释行 (# 开头) 与空行
      - 去除每行首尾空白 (统一缩进差异)
      - 折叠连续空白为单空格

    这样 N 个宇宙中仅空白/注释不同的实现不会膨胀解空间 |S(p)|.
    """
    out_lines: List[str] = []
    for raw in code.splitlines():
        line = raw.strip()
        if not line:
            continue
        # 跳过纯注释行 (Python 风格, 兼容行内注释后置的情况由 strip 处理前缀)
        if line.startswith("#"):
            continue
        # 折叠行内连续空白
        parts = line.split()
        out_lines.append(" ".join(parts))
    return "\n".join(out_lines)


def prompt_quality(report: "PWPReport") -> float:
    """Prompt 质量熵判据 Q(p) (第 18.1 节).

        Q(p) = 1 - H(x|p) / H_max
        H(x|p) = -Σ P(x|p) log P(x|p)   (LLM 输出分布的香农熵, 自然对数)
        H_max  = log|S(p)|              (解空间均匀分布时的最大熵)

    其中 S(p) 为 prompt p 的解空间, 通过 N 次宇宙采样的去重归一化输出
    来经验估计 (见 _normalize_code).

    特例:
      |S|=1 (所有宇宙输出一致) → H=0, H_max=0 → Q(p)=1 (理想 prompt)
      |S|=N (每个宇宙都不同)   → H=log N=H_max → Q(p)=0 (最差 prompt)
      N=0                     → Q(p)=0.0 (无样本)

    与 UCS 的关系 (第 18.1 节定理: UCS 是 Q(p) 的经验估计):
      UCS 关注「公约函数占比」(结构级), Q(p) 关注「输出分布熵」(整体级);
      两者偏离时提示分布形态:
        Q(p) >> UCS: 解空间大但分布不均 (少数解主导)
        Q(p) ≈ UCS : 分布相对均匀
        Q(p) ≈ 1 ∧ UCS ≈ 1: 唯一解 (D1/D5 路径, degenerate 需人工验证 F1)

    Args:
        report: run() 返回的 PWPReport

    Returns:
        Q(p) ∈ [0, 1]
    """
    n = len(report.universes)
    if n == 0:
        return 0.0
    # 统计每个不同归一化输出出现的次数
    counts: dict = {}
    for u in report.universes:
        key = _normalize_code(u.code)
        counts[key] = counts.get(key, 0) + 1
    s_size = len(counts)  # |S(p)| 经验解空间大小
    if s_size <= 1:
        # 唯一解 (含 degenerate): 理想 prompt, H=0 → Q(p)=1
        # 注: degenerate 时 Q(p)=1 但可能是 F1, 由 decide() 的 D5 路径处理
        return 1.0
    # 香农熵 (自然对数, 与 H_max=log|S| 同底)
    h = 0.0
    for cnt in counts.values():
        p = cnt / n
        h -= p * math.log(p)
    h_max = math.log(s_size)
    if h_max <= 0:
        return 1.0
    # 钳制到 [0,1]: 浮点误差可能使均匀分布时 Q 得到极小负数 (如 -2e-16)
    return max(0.0, min(1.0, 1.0 - h / h_max))


# ──────────────────────────────────────────────────────────────
# L8*** 形式化验证互补层 (Formal Verification Complement)  —— 第 19.3 节 CT1-CT4
#
# PWP-QA 可证不一致 (孤岛/IO 不等价) 但不可证正确性 (F1 全宇宙同错).
# 形式化验证 V(f) 可证正确性但成本高. CT1-CT4 给出二者互补的最优工作流:
#
#   CT1 (验证优先):   V(f)=✓ ⟹ 不需要 P(f)
#   CT2 (验证反馈):   V(f)=✗ ⟹ P(f) 应标记 f 为孤岛
#   CT3 (PWP 不替代验证): P(f) UCS=1 ∧ IO 全等价 ⟹ V(f) 仍可能 ✓ 或 ✗
#   CT4 (PWP 聚焦验证): P(f) 有孤岛 ⟹ V(f) 应针对孤岛 (O(|outliers|) << O(|code|))
#
# 本层不绑定具体形式化验证工具 (Coq/Lean/Dafny/...), 只提供整合胶水:
#   - FormalVerificationResult: 单个函数的 V(f) 结果 (由外部工具填充)
#   - FormalVerificationPlan:   综合 CT1-CT4 的验证计划
#   - ct1_should_skip_pwp / ct2_mark_verified_bugs /
#     ct3_needs_verification / ct4_focus_verification_targets: 四个定理实现
#   - plan_formal_verification: 主入口, 生成最优验证计划
# ──────────────────────────────────────────────────────────────

@dataclass
class FormalVerificationResult:
    """单个函数 f 的形式化验证结果 V(f) (第 19.3 节设定).

    Attributes:
        signature: 函数签名 (如 "div(a, b)"), 与 FunctionDef.signature 对齐
        passed:    True=V(f)=✓ (满足 spec), False=V(f)=✗ (不满足 spec),
                   None=未验证
        spec:      验证用的规约描述 (可选, 用于报告)
        tool:      使用的形式化验证工具 (可选, 如 "coq"/"lean"/"dafny")
        evidence:  验证证据 (证明项/反例, 可选)
    """
    signature: str
    passed: Optional[bool] = None
    spec: Optional[str] = None
    tool: Optional[str] = None
    evidence: Optional[str] = None

    @property
    def verified(self) -> bool:
        """是否已经被验证过 (passed 非 None)"""
        return self.passed is not None


@dataclass
class FormalVerificationPlan:
    """综合 CT1-CT4 的形式化验证计划.

    Attributes:
        skip_pwp:            CT1: 是否可跳过 PWP-QA (所有函数已 V=✓)
        focus_targets:       CT4: 应优先验证的函数签名列表 (孤岛 + IO 不等价分叉)
        needs_verification:  CT3: PWP 结果是否仍需形式化验证补充
        verified_bugs:       CT2: 已被 V(f)=✗ 标记的函数签名列表
        newly_marked_outliers: CT2 后新增的孤岛数
        total_functions:     报告中的总函数数
        focus_ratio:         |focus_targets| / |total_functions| (CT4 成本降低比)
        rationale:           人类可读的计划说明
    """
    skip_pwp: bool
    focus_targets: List[str]
    needs_verification: bool
    verified_bugs: List[str]
    newly_marked_outliers: int
    total_functions: int
    focus_ratio: float
    rationale: str

    def to_markdown(self) -> str:
        lines = [
            "## L8*** 形式化验证计划 (第 19.3 节 CT1-CT4)",
            "",
            f"- **CT1 跳过 PWP**: `{self.skip_pwp}` "
            f"({'所有函数已形式化验证通过' if self.skip_pwp else '仍需 PWP-QA'})",
            f"- **CT3 仍需验证**: `{self.needs_verification}` "
            f"({'UCS=1 ∧ IO 全等价 ≠ 正确, 需 V(f) 补充' if self.needs_verification else 'PWP 已发现异常, 走 CT4 聚焦'})",
            f"- **CT4 聚焦目标**: {len(self.focus_targets)} 个函数 "
            f"(占 {self.focus_ratio*100:.0f}%, O(|outliers|) << O(|code|))",
        ]
        if self.focus_targets:
            lines.append("  ```")
            for t in self.focus_targets[:20]:
                lines.append(f"  - {t}")
            if len(self.focus_targets) > 20:
                lines.append(f"  - ...({len(self.focus_targets)-20} 省略)")
            lines.append("  ```")
        if self.verified_bugs:
            lines.append(f"- **CT2 已标记 bug**: {len(self.verified_bugs)} 个")
            for b in self.verified_bugs[:10]:
                lines.append(f"  - `{b}` (V=✗ → 标记为孤岛)")
        lines.append(f"- **理由**: {self.rationale}")
        return "\n".join(lines)


def ct1_should_skip_pwp(
    verification_results: List[FormalVerificationResult],
) -> bool:
    """CT1 (验证优先): V(f)=✓ ⟹ 不需要 P(f).

    若所有函数都已被形式化验证通过 (V=✓), 则 PWP-QA 无问题可发现,
    可跳过. 只要存在未验证或验证失败的函数, PWP-QA 仍有价值.

    Args:
        verification_results: 各函数的 V(f) 结果列表

    Returns:
        True 表示可跳过 PWP-QA (全部 V=✓)
    """
    if not verification_results:
        return False  # 无验证结果, PWP 不能跳过
    return all(r.verified and r.passed for r in verification_results)


def ct2_mark_verified_bugs(
    triage,
    verification_results: List[FormalVerificationResult],
) -> int:
    """CT2 (验证反馈): V(f)=✗ ⟹ P(f) 应标记 f 为孤岛.

    形式化验证发现 bug 的函数, 即使是公约数 (所有宇宙都这么写),
    也应从"可信公约数"重新标记为"已知 bug 孤岛".

    支持行级 Triage 和 AST 级 FunctionTriage (按 signature 匹配).

    Args:
        triage: Triage 或 FunctionTriage 对象 (原地修改)
        verification_results: 各函数的 V(f) 结果列表

    Returns:
        新标记为孤岛的函数数
    """
    buggy_sigs = {
        r.signature for r in verification_results
        if r.verified and r.passed is False
    }
    if not buggy_sigs:
        return 0

    newly_marked = 0
    outliers = getattr(triage, "outliers", [])
    existing_outlier_sigs = {sig for sig, _ in outliers}

    # 从 consensus 中移除已验证为 bug 的函数
    consensus = getattr(triage, "consensus", None)
    if consensus is not None:
        before = len(consensus)
        # 行级: consensus 是 List[str]; AST 级也是 List[str] (函数签名)
        triage.consensus = [c for c in consensus if c not in buggy_sigs]
        removed = before - len(triage.consensus)
        for sig in buggy_sigs:
            if sig in {c for c in consensus}:
                if sig not in existing_outlier_sigs:
                    outliers.append((sig, -1))  # -1 表示"形式化验证发现"
                    existing_outlier_sigs.add(sig)
                    newly_marked += 1
        _ = removed  # removed 恒等于 newly_marked (每个 buggy sig 移除一个)

    # 从 branching 中移除已验证为 bug 的函数变体
    branching = getattr(triage, "branching", None)
    if branching is not None:
        new_branching = []
        for entry in branching:
            sig = entry[0]
            if sig in buggy_sigs:
                if sig not in existing_outlier_sigs:
                    outliers.append((sig, -1))
                    existing_outlier_sigs.add(sig)
                    newly_marked += 1
                # 丢弃整个分叉 (该函数有 bug)
            else:
                new_branching.append(entry)
        triage.branching = new_branching

    return newly_marked


def ct3_needs_verification(report: "PWPReport") -> bool:
    """CT3 (PWP 不能替代验证): P(f) UCS=1 ∧ IO 全等价 ⟹ V(f) 仍不确定.

    即使 PWP-QA 显示 UCS 很高且无孤岛无 IO 不等价, 也不能保证代码正确
    (F1 失败模式: 全宇宙同错). 此时需要形式化验证补充.

    判断条件:
      - σ ∈ {unique, multi, degenerate} (已收敛, 非 ambiguous)
      - 无孤岛 (outliers 为空)
      - 无 IO 不等价分叉 (或未测 IO)
    满足以上条件时, PWP 未发现异常, 但正确性仍需 V(f) 确认.

    Args:
        report: run() 返回的 PWPReport

    Returns:
        True 表示仍需形式化验证补充
    """
    sigma = report.metrics.solution_space
    has_out = _has_outliers(report.triage)
    _, has_io_div = _io_branch_status(report.triage)

    # 有孤岛或 IO 不等价 → PWP 已发现问题, 走 CT4 聚焦验证
    if has_out or has_io_div:
        return True
    # ambiguous 且无孤岛/IO 不等价 → prompt 本身有问题, 先重写 prompt 不谈验证
    if sigma == "ambiguous":
        return False
    # unique/multi/degenerate 且无异常 → F1 风险, 需 V(f) 补充 (CT3)
    return True


def ct4_focus_verification_targets(report: "PWPReport") -> List[str]:
    """CT4 (PWP 聚焦验证): P(f) 有孤岛 ⟹ V(f) 应针对孤岛.

    形式化验证资源有限, 应优先验证高风险区域:
      1. 孤岛函数 (只在个别宇宙出现, F2/F3 高风险)
      2. IO 不等价分叉的函数 (不同变体行为不同, 必有 bug)
    把 O(|code|) 的全量验证降为 O(|outliers| + |io_inequivalent_branches|).

    Args:
        report: run() 返回的 PWPReport

    Returns:
        应优先验证的函数签名列表 (去重, 孤岛在前)
    """
    targets: List[str] = []
    seen: set = set()

    # 1. 孤岛 (最高优先级)
    for sig, _ in getattr(report.triage, "outliers", []) or []:
        if sig not in seen:
            seen.add(sig)
            targets.append(sig)

    # 2. IO 不等价分叉
    branching = getattr(report.triage, "branching", []) or []
    for entry in branching:
        # AST: (sig, List[FunctionVariant]); 行级: (line, List[uid])
        variants = entry[1] if isinstance(entry, (tuple, list)) and len(entry) > 1 else []
        sig = entry[0]
        if isinstance(variants, list):
            for v in variants:
                if getattr(v, "io_equivalent", None) is False:
                    if sig not in seen:
                        seen.add(sig)
                        targets.append(sig)
                    break

    return targets


def plan_formal_verification(
    report: "PWPReport",
    verification_results: Optional[List[FormalVerificationResult]] = None,
) -> FormalVerificationPlan:
    """综合 CT1-CT4 生成形式化验证计划 (第 19.4 节最优工作流).

    工作流:
      1. CT1: 若所有函数已 V=✓ → 跳过 PWP (skip_pwp=True)
      2. CT2: 将 V=✗ 的函数标记为孤岛 (原地修改 triage)
      3. CT3: 判断 PWP 结果是否仍需 V(f) 补充
      4. CT4: 计算聚焦验证目标 (孤岛 + IO 不等价分叉)

    Args:
        report: run() 返回的 PWPReport
        verification_results: 外部形式化验证结果 (可选, None 时只做 CT3+CT4)

    Returns:
        FormalVerificationPlan
    """
    verification_results = verification_results or []

    # CT1
    skip_pwp = ct1_should_skip_pwp(verification_results)

    # CT2 (原地修改 triage)
    newly_marked = ct2_mark_verified_bugs(report.triage, verification_results)
    verified_bugs = [
        r.signature for r in verification_results
        if r.verified and r.passed is False
    ]

    # CT3
    needs_verif = ct3_needs_verification(report)

    # CT4
    targets = ct4_focus_verification_targets(report)
    total_funcs = getattr(report.triage, "total", 0) or 1
    focus_ratio = len(targets) / total_funcs if total_funcs > 0 else 0.0

    # 理由
    if skip_pwp:
        rationale = "CT1: 所有函数已形式化验证通过 (V=✓), PWP-QA 可跳过."
    elif verified_bugs:
        rationale = (
            f"CT2: 形式化验证发现 {len(verified_bugs)} 个 bug 函数, "
            f"已标记为孤岛; CT4: 聚焦验证 {len(targets)} 个高风险函数."
        )
    elif targets:
        rationale = (
            f"CT4: PWP 发现 {len(targets)} 个高风险函数 (孤岛/IO 不等价), "
            f"形式化验证应聚焦于此 (成本比 {focus_ratio*100:.0f}%)."
        )
    elif needs_verif:
        rationale = (
            "CT3: PWP 未发现异常 (UCS 高, 无孤岛), 但不保证正确 "
            "(F1 风险), 建议对公约数做形式化验证."
        )
    else:
        rationale = "σ=ambiguous, 先重写 prompt, 暂不考虑形式化验证."

    return FormalVerificationPlan(
        skip_pwp=skip_pwp,
        focus_targets=targets,
        needs_verification=needs_verif,
        verified_bugs=verified_bugs,
        newly_marked_outliers=newly_marked,
        total_functions=total_funcs,
        focus_ratio=focus_ratio,
        rationale=rationale,
    )


# ──────────────────────────────────────────────────────────────
# 主管道 + 报告
# ──────────────────────────────────────────────────────────────

@dataclass
class PWPReport:
    """PWP-QA 完整报告"""
    prompt: str
    universes: List[Universe]
    triage: Triage
    signal: QASignal
    metrics: Metrics
    alignment: List[List[float]] = field(default_factory=list)
    level: str = "line"  # "line" or "ast"
    io_tested: bool = False  # 是否跑了 L2.5 语义层 IO 等价测试
    prompt_suggestions: List[str] = field(default_factory=list)  # L6 反向优化建议

    def to_markdown(self) -> str:
        is_ast = self.level == "ast"
        unit = "函数" if is_ast else "行"
        out: List[str] = []
        out.append("# PWP-QA 报告")
        out.append("")
        out.append(f"**Prompt**: `{self.prompt}`")
        out.append(f"**N (宇宙数)**: {self.metrics.n}")
        out.append(f"**对齐层级**: {'AST 函数级 (tree-sitter)' if is_ast else '行级 (difflib)'}")
        out.append("")

        out.append("## L5 度量")
        out.append(f"- **UCS** (一致性分数): `{self.metrics.ucs:.3f}`")
        out.append(f"- **鲁棒性** (1 - 孤岛率): `{self.metrics.robustness:.3f}`")
        out.append(f"- **收敛度** (1 - 分叉率): `{self.metrics.convergence:.3f}`")
        out.append(
            f"- **孤岛严重度** (孤岛占比): `{self.metrics.outlier_severity:.3f}`"
        )
        out.append(
            f"- **分歧密度** (平均分叉变体数): "
            f"`{self.metrics.divergence_density:.2f}`"
        )
        out.append("")
        if not self.metrics.converged:
            _thr_disp = load_thresholds().get("ucs_converged", 0.6)
            out.append(f"> ⚠ **铁律 3 触发**: UCS < {_thr_disp}, 分布未收敛")
            out.append("> 停止单宇宙 review, 回头改 prompt")
            out.append("")

        out.append("## L4 QA 信号")
        out.append(f"- {self.signal.consensus_action}: {self.signal.consensus_count} {unit}")
        out.append(f"- {self.signal.branching_action}: {self.signal.branching_count} 处")
        out.append(f"- {self.signal.outlier_action}: {self.signal.outlier_count} 个")
        out.append("")

        out.append("## L3 差异三分")
        out.append("### 公约数 (必然骨架)")
        if self.triage.consensus:
            for l in self.triage.consensus[:30]:
                out.append(f"- `{l}`")
            rest = len(self.triage.consensus) - 30
            if rest > 0:
                out.append(f"- ...({rest} {unit}省略)")
        else:
            out.append("- (空)")
        out.append("")

        if self.triage.outliers:
            out.append("### 孤岛 (强制 review, bug 候选)")
            for sig, uid in self.triage.outliers[:30]:
                out.append(f"- 宇宙 U{uid}: `{sig}`")
            rest = len(self.triage.outliers) - 30
            if rest > 0:
                out.append(f"- ...({rest} 个省略)")
            out.append("")

        if self.triage.branching:
            out.append("### 分叉 (实现选项)")
            if is_ast:
                # AST 模式: 展示每个函数的多个变体, 区分 IO 等价状态
                for sig, variants in self.triage.branching[:15]:
                    out.append(f"- **`{sig}`** — {len(variants)} 个变体")
                    for v in variants:
                        uids_str = ",".join(f"U{u}" for u in v.universes)
                        body_first = v.body_text.strip().splitlines()[0] if v.body_text.strip() else ""
                        tags = []
                        if v.io_equivalent is True:
                            tags.append("✓ IO 等价 (风格差异)")
                        elif v.io_equivalent is False:
                            tags.append("✗ IO 不等价 (真 bug)")
                        # 不变量检查 (属性测试, 非确定性函数)
                        if v.invariants is not None:
                            if v.invariants_pass:
                                tags.append("✓ 不变量通过")
                            else:
                                failed = [n for n, p in v.invariants if not p]
                                tags.append(f"✗ 不变量失败: {','.join(failed)}")
                        tag = " " + " | ".join(tags) if tags else " (未测)"
                        out.append(f"  - [{uids_str}] `{body_first}`{tag}")
            else:
                for line, uids in self.triage.branching[:15]:
                    uids_str = ",".join(f"U{u}" for u in uids)
                    out.append(f"- `{line}` ← {uids_str}")
            rest = len(self.triage.branching) - 15
            if rest > 0:
                out.append(f"- ...({rest} 处省略)")
            out.append("")

        out.append("## 三条铁律自检")
        out.append(f'1. ✓ 审"公约数"而非"那一版": {self.signal.consensus_count} {unit}公约数')
        out.append(f"2. 孤岛优先级: {self.signal.outlier_count} 个孤岛等待 review")
        _thr_r3 = load_thresholds().get("ucs_converged", 0.6)
        rule3 = (f"⚠ 触发 (UCS<{_thr_r3}, 停审回头改 prompt)"
                 if not self.metrics.converged else f"✓ UCS≥{_thr_r3}")
        out.append(f"3. {rule3}")
        out.append("")

        # L6 反向 Prompt 优化建议 (UCS 未收敛时自动填充)
        if self.prompt_suggestions:
            out.append("## L6 反向 Prompt 优化建议")
            out.append(
                f"触发条件: UCS={self.metrics.ucs:.3f} < {_thr_r3}, 分布未收敛."
            )
            out.append("")
            for i, s in enumerate(self.prompt_suggestions, 1):
                out.append(f"{i}. {s}")
            out.append("")
            out.append(
                f'> 按"铁律 3": 改完 prompt 重新跑 PWP-QA 直到 UCS≥{_thr_r3}.'
            )
            out.append("")

        return "\n".join(out)


def run(
    prompt: str,
    generator: GeneratorFn,
    n: int = 5,
    seeds: Optional[List[int]] = None,
    level: str = "line",
    test_generator: Optional[Callable[[str, str, str, str], List[TestCase]]] = None,
    invariant_checker: Optional[Callable[[str, str], List[Tuple[str, bool]]]] = None,
) -> PWPReport:
    """
    运行完整 PWP-QA 流水线

    L1 生成 -> L2 对齐 -> L3 三分 -> L4 信号 -> L5 度量
    可选 L2.5 语义层:
      - test_generator: (fn_name, params, prompt, sample_code) -> List[TestCase]
        对 AST 模式 branching 变体跑精确 IO 等价测试 (确定性函数)
      - invariant_checker: (fn_code, fn_name) -> [(name, passed), ...]
        对 AST 模式 branching 变体跑不变量检查 (非确定性函数, 如用 random 的)

    level: "line" (行级, 默认) 或 "ast" (tree-sitter 函数级, 修复行级误判)
    """
    # L1
    universes = generate_universes(prompt, generator, n, seeds)
    # L2 (对齐矩阵供报告展示)
    alignment = alignment_matrix(universes)
    # L3
    if level == "ast":
        if not _TS_AVAILABLE:
            raise ImportError(
                "AST 模式需要 tree-sitter; pip install tree-sitter tree-sitter-python"
            )
        triage = triage_universes_ast(
            universes, test_generator=test_generator, prompt=prompt,
            invariant_checker=invariant_checker,
        )
    else:
        triage = triage_universes(universes)
    # L4
    signal = extract_qa_signal(triage)
    # L5
    metrics = compute_metrics(triage, n)
    # L6 反向 Prompt 优化 (UCS<阈值时自动生成改进建议)
    suggestions = suggest_prompt_improvements(triage, metrics, prompt)
    report = PWPReport(
        prompt=prompt,
        universes=universes,
        triage=triage,
        signal=signal,
        metrics=metrics,
        alignment=alignment,
        level=level,
        io_tested=(test_generator is not None and level == "ast"),
        prompt_suggestions=suggestions,
    )
    log_run_to_trend(report)  # L0* 写趋势 (失败静默)
    return report


async def run_async(
    prompt: str,
    generator: Callable[..., Any],
    n: int = 5,
    seeds: Optional[List[int]] = None,
    level: str = "line",
    concurrency: int = 5,
    test_generator: Optional[Callable[[str, str, str, str], List[TestCase]]] = None,
    invariant_checker: Optional[Callable[[str, str], List[Tuple[str, bool]]]] = None,
) -> PWPReport:
    """
    异步运行完整 PWP-QA 流水线 (真实 LLM 推荐)

    generator 接受同步或 async 函数; 同步会被 to_thread 包装并发执行
    test_generator 同步函数, 在 L3 阶段对 branching 变体跑 IO 测试
    invariant_checker 同步函数, 在 L3 阶段对 branching 变体跑不变量检查
    """
    universes = await generate_universes_async(
        prompt, generator, n, seeds, concurrency=concurrency
    )
    alignment = alignment_matrix(universes)
    if level == "ast":
        if not _TS_AVAILABLE:
            raise ImportError(
                "AST 模式需要 tree-sitter; pip install tree-sitter tree-sitter-python"
            )
        triage = triage_universes_ast(
            universes, test_generator=test_generator, prompt=prompt,
            invariant_checker=invariant_checker,
        )
    else:
        triage = triage_universes(universes)
    signal = extract_qa_signal(triage)
    metrics = compute_metrics(triage, n)
    suggestions = suggest_prompt_improvements(triage, metrics, prompt)
    report = PWPReport(
        prompt=prompt,
        universes=universes,
        triage=triage,
        signal=signal,
        metrics=metrics,
        alignment=alignment,
        level=level,
        io_tested=(test_generator is not None and level == "ast"),
        prompt_suggestions=suggestions,
    )
    log_run_to_trend(report)
    return report


# ──────────────────────────────────────────────────────────────
# L7 闭环自动收敛 (Auto-Convergence Loop)
# 把 L6 "建议改 prompt" 升级为 "自动改 prompt + 重跑, 直到 UCS≥0.5"
# ──────────────────────────────────────────────────────────────

@dataclass
class ConvergenceIteration:
    """闭环中一次迭代 (一个 prompt -> 一次 run)"""
    iter_num: int                 # 1-based
    prompt: str
    ucs: float
    n_consensus: int              # 公约数数量
    n_branching: int              # 分叉数量
    n_outliers: int               # 孤岛数量
    converged: bool               # UCS >= target
    suggestions: List[str] = field(default_factory=list)
    prompt_changed: bool = False  # 这次迭代是否改写了 prompt (即上轮触发了 rewrite)
    # 不变量门状态: None=未启用, True=全部已检查变体通过且无 IO 不等价
    invariant_ok: Optional[bool] = None


def convergence_speed(iterations: List[ConvergenceIteration],
                      target_ucs: float) -> Tuple[float, Optional[int]]:
    """第 18.4 节收敛速度: 从迭代轨迹估计 ε 与预测收敛轮数 T.

    ε (improvement_rate) = 平均每次 prompt 改写带来的 UCS 提升量.
        仅统计 prompt_changed=True 的迭代 (即上一轮做了 rewrite 的轮次),
        取 UCS 相对上一轮的增量的均值. 若不足 2 轮或无正向增量, ε=0.
    T (predicted_iters)  = ⌈(target - UCS₀) / ε⌉  (ε>0 时);
        UCS₀ 为第一轮 UCS. ε≤0 时 T=None (无法预测, 可能振荡或已收敛).

    Returns:
        (eps, predicted_iters)
    """
    if not iterations:
        return 0.0, None

    ucs0 = iterations[0].ucs
    # 已收敛: 无论轨迹长短, 预测轮数为 0
    if target_ucs <= ucs0:
        return 0.0, 0

    if len(iterations) < 2:
        return 0.0, None

    deltas: List[float] = []
    for i in range(1, len(iterations)):
        if iterations[i].prompt_changed:
            deltas.append(iterations[i].ucs - iterations[i - 1].ucs)

    if not deltas:
        return 0.0, None

    eps = sum(deltas) / len(deltas)
    if eps <= 0:
        return eps, None

    predicted = math.ceil((target_ucs - ucs0) / eps)
    return eps, max(predicted, 1)


@dataclass
class ConvergenceReport:
    """闭环收敛报告"""
    original_prompt: str
    final_prompt: str
    iterations: List[ConvergenceIteration] = field(default_factory=list)
    converged: bool = False
    total_iters: int = 0
    # "converged" | "invariant_satisfied" | "max_iter" | "oscillated"
    # | "no_llm" | "no_suggestions"
    reason: str = "max_iter"
    final_ucs: float = 0.0
    # 第 18.4 节收敛速度
    improvement_rate: float = 0.0          # ε: 每次改写的平均 UCS 提升
    predicted_iters: Optional[int] = None  # T: 预测还需多少轮收敛 (None=无法预测)

    def to_markdown(self) -> str:
        out: List[str] = ["# L7 闭环自动收敛报告", ""]
        out.append(f"**原 Prompt**: `{self.original_prompt[:80]}{'...' if len(self.original_prompt) > 80 else ''}`")
        out.append(f"**终 Prompt**: `{self.final_prompt[:80]}{'...' if len(self.final_prompt) > 80 else ''}`")
        out.append(f"**收敛**: {'✅ 是' if self.converged else '❌ 否'}")
        out.append(f"**终止原因**: `{self.reason}`")
        out.append(f"**总迭代数**: {self.total_iters}")
        out.append(f"**最终 UCS**: `{self.final_ucs:.3f}`")
        # 第 18.4 节收敛速度
        if self.improvement_rate > 0:
            out.append(f"**收敛速度 ε**: `{self.improvement_rate:.4f}/轮` "
                       f"(每次改写平均 UCS 提升)")
            if self.predicted_iters is not None:
                if self.converged:
                    out.append(f"**预测收敛轮数 T**: {self.predicted_iters} "
                               f"(已收敛, 实际 {self.total_iters} 轮)")
                else:
                    out.append(f"**预测还需轮数 T**: {self.predicted_iters} "
                               f"(T=⌈(target-UCS₀)/ε⌉)")
        elif self.predicted_iters is None and self.total_iters >= 2:
            out.append("**收敛速度 ε**: `≤0` (改写未带来 UCS 提升, 可能振荡或 prompt 已无改进空间)")
        out.append("")
        out.append("## 迭代轨迹")
        out.append("")
        out.append("| iter | UCS | 公约 | 分叉 | 孤岛 | 收敛 | 不变量 | 改 prompt |")
        out.append("|------|-----|------|------|-------|------|--------|-----------|")
        for it in self.iterations:
            conv = "✓" if it.converged else " "
            chg = "✓" if it.prompt_changed else " "
            inv = ("✓" if it.invariant_ok else "✗") if it.invariant_ok is not None else "-"
            out.append(
                f"| {it.iter_num} | {it.ucs:.3f} | {it.n_consensus} | "
                f"{it.n_branching} | {it.n_outliers} | {conv} | {inv} | {chg} |"
            )
        out.append("")
        if self.reason == "converged":
            out.append(f"> ✅ 第 {self.total_iters} 轮达到 UCS≥{self.iterations[-1].ucs:.3f}, 闭环收敛.")
        elif self.reason == "invariant_satisfied":
            out.append(
                f"> ✅ 第 {self.total_iters} 轮 UCS={self.final_ucs:.3f} 未达阈值, "
                "但所有已检查分叉变体均通过不变量且无 IO 不等价变体 — "
                "结构不收敛但语义达标 (不变量门, P0-3 第二验收通道)."
            )
        elif self.reason == "max_iter":
            out.append(f"> ⚠ 达到最大迭代数 ({self.total_iters}) 仍未收敛 (UCS={self.final_ucs:.3f}).")
        elif self.reason == "oscillated":
            out.append("> ⚠ 检测到 UCS 连续下降 (振荡), 提前终止避免死循环.")
        elif self.reason == "no_llm":
            out.append("> ⚠ 未提供 `llm_generator_for_rewrite`, 无法自动改 prompt (停在第一轮建议).")
        elif self.reason == "no_suggestions":
            out.append("> ⚠ 无 L6 建议 (可能 UCS 已收敛或无典型问题), 无需改 prompt.")
        out.append("")
        return "\n".join(out)


def _count_triage_parts(triage: Triage) -> Tuple[int, int, int]:
    """从 triage (行级或 AST) 取出 (公约数, 分叉, 孤岛) 数量"""
    return (
        len(triage.consensus),
        len(triage.branching),
        len(triage.outliers),
    )


def triage_invariant_stats(triage) -> dict:
    """汇总 AST 三分中分叉变体的不变量/IO 等价状态 (不变量门判定依据).

    仅对 FunctionTriage (AST 级) 有效; 行级 Triage 没有语义层, 返回 checked=0.

    Returns:
        checked:         跑了不变量检查的变体数
        failed:          有任一不变量未通过的变体数
        io_inequivalent: IO 测试判定不等价 (真 bug) 的变体数
        failed_names:    所有失败的不变量名 (去重排序)
    """
    stats = {"checked": 0, "failed": 0, "io_inequivalent": 0, "failed_names": []}
    if not isinstance(triage, FunctionTriage):
        return stats
    names: set = set()
    for _sig, variants in triage.branching:
        for v in variants:
            if v.io_equivalent is False:
                stats["io_inequivalent"] += 1
            if v.invariants is None:
                continue
            stats["checked"] += 1
            failed = [name for name, ok in v.invariants if not ok]
            if failed:
                stats["failed"] += 1
                names.update(failed)
    stats["failed_names"] = sorted(names)
    return stats


def _invariant_gate_pass(triage) -> Optional[bool]:
    """不变量门判定: 结构不收敛时语义是否达标.

    True  = 至少 1 个变体被检查, 且全部通过, 且无 IO 不等价变体
    False = 有不变量失败或 IO 不等价
    None  = 非 AST 三分或无变体被检查 (门不适用)
    """
    stats = triage_invariant_stats(triage)
    if stats["checked"] == 0:
        return None
    return stats["failed"] == 0 and stats["io_inequivalent"] == 0


def run_until_converged(
    prompt: str,
    generator: GeneratorFn,
    max_iter: int = 5,
    target_ucs: float = 0.5,
    llm_generator_for_rewrite: Optional[GeneratorFn] = None,
    n: int = 5,
    seeds: Optional[List[int]] = None,
    level: str = "ast",
    test_generator: Optional[Callable[[str, str, str, str], List[TestCase]]] = None,
    invariant_checker: Optional[Callable[[str, str], List[Tuple[str, bool]]]] = None,
    oscillation_threshold: float = 0.05,
    async_mode: bool = False,
    concurrency: int = 5,
) -> ConvergenceReport:
    """
    闭环: run -> 检 UCS -> (低则) auto_rewrite_prompt -> 重跑, 直到:
      - converged:           UCS >= target_ucs
      - invariant_satisfied: UCS < target 但不变量门达标 (第二验收通道, P0-3 修复)
      - max_iter:            达到 max_iter
      - oscillated:          UCS 连续下降 (后一轮 < 前一轮 - threshold) 提前终止
      - no_llm:              UCS 未收敛但没提供 llm_generator_for_rewrite
      - no_suggestions:      UCS 未收敛但 L6 给不出建议

    不变量门 (invariant_satisfied): 提供 invariant_checker 且 level="ast" 时,
    每轮先查 UCS, 不达标再查不变量门 — 所有已检查分叉变体不变量全过
    且无 IO 不等价变体 => 结构不收敛但语义达标, 判收敛.
    实证背景 (P0-3, hive_l7_converge.py): ambiguous prompt 的内在分歧
    (LLM 发明不同辅助结构) 靠改写 prompt 无法消除, UCS 永远卡在 0,
    不变量门是这类场景的唯一验收路径.

    Args:
        prompt:                    原 prompt
        generator:                 生成代码的 generator (prompt, seed) -> str
        max_iter:                  最大迭代次数
        target_ucs:                收敛阈值 (默认 0.5, 与经验校准阈值一致)
        llm_generator_for_rewrite: 改写 prompt 用的 LLM; None 则不能自动改
        n, seeds, level, test_generator: 透传给 run()
        invariant_checker:         不变量检查器 (full_code, fn_name) ->
                                   [(name, passed), ...]; 透传给 run() 并启用不变量门
        oscillation_threshold:    振荡判定阈值 (UCS 下降超过此值视为在变差)
        async_mode:                True 时用 run_async (真实 LLM 推荐)
        concurrency:               async_mode 下的并发数
    """
    import asyncio

    cur_prompt = prompt
    history: List[ConvergenceIteration] = []

    def _do_run(p: str) -> PWPReport:
        if async_mode:
            return asyncio.run(
                run_async(
                    p, generator, n=n, seeds=seeds, level=level,
                    concurrency=concurrency, test_generator=test_generator,
                    invariant_checker=invariant_checker,
                )
            )
        return run(
            p, generator, n=n, seeds=seeds, level=level,
            test_generator=test_generator,
            invariant_checker=invariant_checker,
        )

    def _make_report(converged: bool, reason: str,
                     final_ucs: float, total_iters: int) -> ConvergenceReport:
        """构造带收敛速度 (第 18.4 节) 的 ConvergenceReport."""
        eps, predicted = convergence_speed(history, target_ucs)
        return ConvergenceReport(
            original_prompt=prompt,
            final_prompt=cur_prompt,
            iterations=history,
            converged=converged,
            total_iters=total_iters,
            reason=reason,
            final_ucs=final_ucs,
            improvement_rate=eps,
            predicted_iters=predicted,
        )

    for i in range(max_iter):
        report = _do_run(cur_prompt)
        n_cons, n_br, n_out = _count_triage_parts(report.triage)
        inv_ok = _invariant_gate_pass(report.triage) if invariant_checker else None
        iter_entry = ConvergenceIteration(
            iter_num=i + 1,
            prompt=cur_prompt,
            ucs=report.metrics.ucs,
            n_consensus=n_cons,
            n_branching=n_br,
            n_outliers=n_out,
            converged=report.metrics.converged,
            suggestions=report.prompt_suggestions,
            prompt_changed=(i > 0),  # i>0 意味着上一轮做了 rewrite
            invariant_ok=inv_ok,
        )
        history.append(iter_entry)

        # 收敛: 直接成功
        if report.metrics.converged or report.metrics.ucs >= target_ucs:
            return _make_report(
                converged=True, reason="converged",
                final_ucs=report.metrics.ucs, total_iters=i + 1,
            )

        # 不变量门 (第二验收通道): UCS 未达标但语义达标 -> 收敛
        if inv_ok:
            return _make_report(
                converged=True, reason="invariant_satisfied",
                final_ucs=report.metrics.ucs, total_iters=i + 1,
            )

        # 振荡检测: UCS 连续下降
        if len(history) >= 2:
            prev_ucs = history[-2].ucs
            cur_ucs = history[-1].ucs
            if cur_ucs < prev_ucs - oscillation_threshold:
                # 第二次连续下降才停 (允许一次波动)
                if len(history) >= 3 and history[-2].ucs < history[-3].ucs - oscillation_threshold:
                    return _make_report(
                        converged=False, reason="oscillated",
                        final_ucs=report.metrics.ucs, total_iters=i + 1,
                    )

        # 没 LLM 改写: 直接停在第一轮
        if llm_generator_for_rewrite is None:
            return _make_report(
                converged=False, reason="no_llm",
                final_ucs=report.metrics.ucs, total_iters=i + 1,
            )

        # L6 没建议: 改不动 prompt
        if not report.prompt_suggestions:
            return _make_report(
                converged=False, reason="no_suggestions",
                final_ucs=report.metrics.ucs, total_iters=i + 1,
            )

        # 用 LLM 改 prompt
        new_prompt = auto_rewrite_prompt(
            report.prompt_suggestions, cur_prompt, llm_generator_for_rewrite
        )
        if new_prompt is None or new_prompt.strip() == cur_prompt.strip():
            return _make_report(
                converged=False, reason="no_llm",
                final_ucs=report.metrics.ucs, total_iters=i + 1,
            )
        cur_prompt = new_prompt

    # 达到 max_iter
    last = history[-1] if history else None
    return _make_report(
        converged=False, reason="max_iter",
        final_ucs=last.ucs if last else 0.0, total_iters=max_iter,
    )


# ──────────────────────────────────────────────────────────────
# CLI (argparse 子命令, 可选)
# 兼容旧入口: python pwp_qa.py --prompt xxx -n 5  -> 等价于 demo 子命令
# 新入口:     python pwp_qa.py run --prompt xxx --backend openai
# ──────────────────────────────────────────────────────────────

def _cli_mock_generator():
    """返回 mock generator (避免依赖外部 API); demo / --backend mock 使用"""
    def mock_gen(prompt: str, seed: Optional[int] = None) -> str:
        rng = random.Random(seed)
        base = (
            "def add(a, b):\n"
            "    return a + b\n"
            "\n"
            "def sub(a, b):\n"
            "    return a - b\n"
        )
        variants = [
            "def mul(a, b):\n    return a * b",
            "def mul(a, b):\n    result = a * b\n    return result",
            "def mul(a, b):\n    return a * b",
        ]
        outliers = [
            "def div(a, b):\n    return a / b  # bug: 整数除法",
            "",
            "",
            "def div(a, b):\n    return a // b  # bug: 错误使用整数除法",
            "",
        ]
        code = base
        code += rng.choice(variants) + "\n"
        out = rng.choice(outliers)
        if out:
            code += out + "\n"
        return code
    return mock_gen


def _cli_pick_backend(backend: str) -> GeneratorFn:
    """根据 --backend 选 generator; 读 env API key / model"""
    if backend == "mock":
        return _cli_mock_generator()
    if backend == "openai":
        return make_openai_generator(
            model=os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
            temperature=0.7,
        )
    if backend == "anthropic":
        return make_anthropic_generator(
            model=os.environ.get("ANTHROPIC_MODEL", "claude-3-5-haiku-20241022"),
            temperature=0.7,
        )
    if backend == "ollama":
        return make_ollama_generator(
            model=os.environ.get("OLLAMA_MODEL", "qwen2.5-coder:7b"),
            temperature=0.7,
        )
    raise ValueError(f"未知 backend: {backend}")


def _cli_cmd_demo(args) -> int:
    """pwp-qa demo: 跑 mock demo (兼容旧入口 python pwp_qa.py)"""
    seeds = [args.seed + i for i in range(args.n)]
    report = run(args.prompt, _cli_mock_generator(), n=args.n, seeds=seeds)
    print(report.to_markdown())
    return 0


def _cli_cmd_run(args) -> int:
    """pwp-qa run: 跑一次多宇宙生成 + 三分 + 报告"""
    generator = _cli_pick_backend(args.backend)
    seeds = [args.seed + i for i in range(args.n)]
    test_gen = generate_test_suite if args.io_test else None
    report = run(
        prompt=args.prompt,
        generator=generator,
        n=args.n,
        seeds=seeds,
        level=args.level,
        test_generator=test_gen,
    )
    print(report.to_markdown())
    if args.radar:
        print()
        print(metrics_bars(report.metrics))
    if args.diagnose:
        print()
        print("## L6 诊断 (Prompt 质量映射)")
        findings = diagnose(report)
        if not findings:
            print("- 无明显问题 ✅")
        else:
            for f in findings:
                print(f"- {f}")
    if args.decide:
        print()
        print(decide(report).to_markdown())
    if args.quality:
        qp = prompt_quality(report)
        print()
        print("## L8** Prompt 质量熵判据 Q(p) (第 18.1 节)")
        print(f"- **Q(p)** = `{qp:.3f}`  (1-H/H_max, ∈[0,1])")
        print(f"- **UCS**  = `{report.metrics.ucs:.3f}`")
        if qp > report.metrics.ucs + 0.05:
            print(f"- Q(p) >> UCS: 解空间较大但分布不均 (少数解主导, 多数零散)")
        elif abs(qp - report.metrics.ucs) <= 0.05:
            print(f"- Q(p) ≈ UCS: 输出分布相对均匀")
        else:
            print(f"- Q(p) < UCS: 公约结构占比高于整体一致性 (少见, 可能有孤立函数分歧)")
    if args.verify:
        print()
        plan = plan_formal_verification(report)
        print(plan.to_markdown())
    return 0


def _cli_cmd_converge(args) -> int:
    """pwp-qa converge: L7 闭环自动收敛"""
    generator = _cli_pick_backend(args.backend)
    # L6 改写 prompt 需要 LLM; mock backend 没法改写 -> 自动走 no_llm 路径
    if args.backend == "mock":
        rewriter: Optional[GeneratorFn] = None
    elif args.rewrite_backend:
        rewriter = _cli_pick_backend(args.rewrite_backend)
    else:
        rewriter = generator  # 默认同 backend
    seeds = [args.seed + i for i in range(args.n)]
    report = run_until_converged(
        prompt=args.prompt,
        generator=generator,
        max_iter=args.max_iter,
        target_ucs=args.target_ucs,
        llm_generator_for_rewrite=rewriter,
        n=args.n,
        seeds=seeds,
        level=args.level,
    )
    print(report.to_markdown())
    print()
    print(
        f"终止原因: {report.reason}  |  最终 UCS: {report.final_ucs:.3f}"
        f"  |  迭代轮数: {report.total_iters}"
    )
    return 0


def _cli_cmd_trend(args) -> int:
    """pwp-qa trend: 历史趋势"""
    print(trend_to_markdown(args.limit))
    return 0


# ──────────────────────────────────────────────────────────────
# Web UI (纯标准库 http.server) — 阶梯 2
# ──────────────────────────────────────────────────────────────

def _svg_sparkline(values: List[float], width: int = 300, height: int = 80,
                   color: str = "#4a9") -> str:
    """把数值列表渲染成 SVG sparkline 折线图."""
    if not values:
        return f'<svg width="{width}" height="{height}"><text x="10" y="40" fill="#888">暂无数据</text></svg>'
    n = len(values)
    lo = min(values) if min(values) < 0 else 0
    hi = max(values) if max(values) > 1 else 1
    rng = hi - lo if hi > lo else 1
    pts = []
    for i, v in enumerate(values):
        x = (i / max(n - 1, 1)) * (width - 20) + 10
        y = height - 10 - ((v - lo) / rng) * (height - 20)
        pts.append(f"{x:.1f},{y:.1f}")
    polyline = " ".join(pts)
    # 0.6 阈值线
    if lo <= 0.6 <= hi:
        ty = height - 10 - ((0.6 - lo) / rng) * (height - 20)
        threshold_line = (
            f'<line x1="10" y1="{ty:.1f}" x2="{width-10}" y2="{ty:.1f}" '
            f'stroke="#e55" stroke-dasharray="4 3" opacity="0.5"/>'
            f'<text x="{width-50}" y="{ty-3:.1f}" fill="#e55" font-size="9">0.6</text>'
        )
    else:
        threshold_line = ""
    return (
        f'<svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">'
        f'<rect width="{width}" height="{height}" fill="#1a1a2e" rx="4"/>'
        f'{threshold_line}'
        f'<polyline points="{polyline}" fill="none" stroke="{color}" '
        f'stroke-width="2" stroke-linejoin="round"/>'
        f'<circle cx="{pts[-1].split(",")[0]}" cy="{pts[-1].split(",")[1]}" '
        f'r="3" fill="{color}"/>'
        f'</svg>'
    )


def _svg_bar(label: str, value: float, max_val: float = 1.0,
             color: str = "#4a9") -> str:
    """单行度量条形图."""
    pct = min(value / max_val, 1.0) if max_val > 0 else 0
    bar_w = int(pct * 200)
    val_str = f"{value:.3f}" if max_val == 1.0 else f"{value:.1f}"
    bar_color = color
    if max_val == 1.0 and value < 0.6:
        bar_color = "#e55"
    return (
        f'<div style="display:flex;align-items:center;gap:8px;margin:2px 0;">'
        f'<span style="width:120px;text-align:right;color:#aaa;font-size:12px;">{label}</span>'
        f'<div style="width:200px;height:14px;background:#333;border-radius:3px;">'
        f'<div style="width:{bar_w}px;height:14px;background:{bar_color};border-radius:3px;"></div>'
        f'</div>'
        f'<span style="color:#fff;font-size:12px;">{val_str}</span>'
        f'</div>'
    )


def _build_web_html(run_result_html: str = "") -> str:
    """构建 Web UI 主页 HTML. run_result_html 为交互式 run 结果."""
    records = load_trend(50)
    baseline = load_baseline()

    # UCS 趋势 sparkline
    ucs_values = [r.get("ucs", 0) for r in records]
    sparkline = _svg_sparkline(ucs_values, width=400, height=100)

    # 统计摘要
    stats = trend_stats(records) or {}

    # 趋势表
    trend_rows = ""
    for i, r in enumerate(records[-20:], 1):
        ts = r.get("ts", 0)
        ts_str = time.strftime("%m-%d %H:%M", time.localtime(ts)) if ts else "-"
        ucs = r.get("ucs", 0)
        space = r.get("solution_space", "-")
        ucs_color = "#4a9" if ucs >= 0.6 else "#e55"
        trend_rows += (
            f"<tr><td>{i}</td><td>{ts_str}</td>"
            f"<td style='color:{ucs_color}'>{ucs:.3f}</td>"
            f"<td>{r.get('robustness',0):.3f}</td>"
            f"<td>{space}</td>"
            f"<td>{r.get('n','-')}</td></tr>"
        )

    # 基线信息
    baseline_section = ""
    if baseline:
        bl_ts = baseline.get("established_at", 0)
        bl_str = time.strftime("%Y-%m-%d %H:%M", time.localtime(bl_ts))
        bl_rows = ""
        for r in baseline.get("results", []):
            ucs = r.get("ucs", 0)
            ucs_color = "#4a9" if ucs >= 0.6 else "#e55"
            bl_rows += (
                f"<tr><td>{r.get('prompt','')[:40]}...</td>"
                f"<td style='color:{ucs_color}'>{ucs:.3f}</td>"
                f"<td>{r.get('solution_space','-')}</td></tr>"
            )
        baseline_section = f"""
        <div class="card">
            <h2>基线 (Continuous Baseline)</h2>
            <p>建立于: <b>{bl_str}</b></p>
            <table>{bl_rows}</table>
        </div>"""

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PWP-QA Dashboard</title>
<style>
  body {{ background: #0f0f1e; color: #eee; font-family: 'Segoe UI', sans-serif; margin: 0; padding: 20px; }}
  h1 {{ color: #6cf; border-bottom: 1px solid #333; padding-bottom: 8px; }}
  h2 {{ color: #4a9; margin-top: 0; }}
  .grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 20px; max-width: 900px; }}
  .card {{ background: #1a1a2e; border-radius: 8px; padding: 16px; margin-bottom: 16px; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
  th, td {{ text-align: left; padding: 4px 8px; border-bottom: 1px solid #2a2a3e; }}
  th {{ color: #6cf; }}
  .stat {{ display: inline-block; margin-right: 20px; }}
  .stat-val {{ font-size: 20px; font-weight: bold; color: #4a9; }}
  .stat-label {{ font-size: 11px; color: #888; }}
</style>
</head>
<body>
<h1>PWP-QA Dashboard</h1>
<p style="color:#888">Parallel Worlds Paradigm for Code QA — 实时监控面板</p>

<div class="card">
  <h2>交互式 Run (mock 模式)</h2>
  <form action="/run" method="POST" style="margin:12px 0;">
    <textarea name="prompt" rows="2" cols="60" placeholder="输入 prompt, 如: 写一个 add(a,b) 函数"
      style="background:#1a1a2e;color:#eee;border:1px solid #444;border-radius:4px;padding:8px;width:70%;"></textarea>
    <input type="number" name="n" value="5" min="3" max="10"
      style="background:#1a1a2e;color:#eee;border:1px solid #444;border-radius:4px;padding:4px;width:50px;margin-left:8px;">
    <button type="submit" style="background:#4a9;color:#fff;border:none;border-radius:4px;padding:8px 20px;cursor:pointer;margin-left:8px;">跑 Run</button>
  </form>
</div>

{run_result_html}

<div class="grid">
  <div class="card">
    <h2>UCS 趋势 (最近 {len(records)} 次 run)</h2>
    {sparkline}
    <div style="margin-top:12px;">
      <div class="stat"><span class="stat-val">{stats.get('ucs_mean',0):.3f}</span><br><span class="stat-label">UCS 均值</span></div>
      <div class="stat"><span class="stat-val">{stats.get('ucs_std',0):.3f}</span><br><span class="stat-label">标准差</span></div>
      <div class="stat"><span class="stat-val">{stats.get('converged_rate',0):.0%}</span><br><span class="stat-label">收敛率</span></div>
      <div class="stat"><span class="stat-val">{stats.get('direction','—')}</span><br><span class="stat-label">趋势方向</span></div>
    </div>
  </div>

  <div class="card">
    <h2>最近 20 次 run 明细</h2>
    <table>
      <tr><th>#</th><th>时间</th><th>UCS</th><th>鲁棒性</th><th>解空间</th><th>N</th></tr>
      {trend_rows}
    </table>
  </div>
</div>

{baseline_section}

<div class="card">
  <h2>关于</h2>
  <p style="color:#888;font-size:13px;">
    PWP-QA 范式: 通过多宇宙平行生成 + AST 三分 + UCS 度量评估 prompt 质量.<br>
    解空间分类: <b style="color:#4a9">unique</b> (唯一解) |
    <b style="color:#6cf">multi</b> (多解型) |
    <b style="color:#fc4">ambiguous</b> (歧义型) |
    <b style="color:#e55">degenerate</b> (退化型)
  </p>
</div>

</body>
</html>"""


def _cli_cmd_web(args) -> int:
    """pwp-qa web: 启动 Web UI (http.server)"""
    import http.server
    import socketserver
    from urllib.parse import parse_qs

    port = args.port
    # Web UI 状态: 存储最近一次交互式 run 的结果
    state = {"last_run_html": ""}

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            # /refresh 只返回刷新后的 HTML
            html = _build_web_html(state.get("last_run_html", ""))
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(html.encode("utf-8"))

        def do_POST(self):
            if self.path != "/run":
                self.send_error(404)
                return
            content_len = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_len).decode("utf-8")
            params = parse_qs(body)
            prompt = params.get("prompt", [""])[0].strip()
            n = int(params.get("n", ["5"])[0])
            if not prompt:
                state["last_run_html"] = (
                    '<div class="card"><h2>错误</h2>'
                    '<p style="color:#e55">prompt 不能为空</p></div>'
                )
            else:
                try:
                    gen = _mock_generator_for_cli()
                    report = run(prompt, gen, n=n, level="ast")
                    state["last_run_html"] = _render_run_result(report, prompt)
                except Exception as e:
                    state["last_run_html"] = (
                        f'<div class="card"><h2>错误</h2>'
                        f'<p style="color:#e55">{str(e)[:200]}</p></div>'
                    )
            # 重定向回首页 (PRG 模式)
            self.send_response(303)
            self.send_header("Location", "/")
            self.end_headers()

        def log_message(self, *a):
            pass

    print(f"PWP-QA Web UI 启动: http://localhost:{port}")
    print(f"POST /run 提交 prompt; GET / 刷新")
    print(f"Ctrl+C 退出")
    with socketserver.TCPServer(("", port), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n已退出")
    return 0


def _render_run_result(report: "PWPReport", prompt: str) -> str:
    """把交互式 run 的结果渲染成 HTML 卡片."""
    m = report.metrics
    space_colors = {
        "unique": "#4a9", "multi": "#6cf",
        "ambiguous": "#fc4", "degenerate": "#e55",
    }
    space_color = space_colors.get(m.solution_space, "#888")

    # 度量条形图
    bars = (
        _svg_bar("UCS", m.ucs) +
        _svg_bar("鲁棒性", m.robustness) +
        _svg_bar("收敛度", m.convergence) +
        _svg_bar("孤岛严重度", m.outlier_severity) +
        _svg_bar("分歧密度", m.divergence_density, max_val=10)
    )

    # 诊断结论
    diags = diagnose(report)
    diag_html = "".join(f"<li>{d}</li>" for d in diags) if diags else "<li>无诊断结论</li>"

    # 三分摘要
    triage = report.triage
    triage_html = (
        f"<tr><td>公约数</td><td>{len(triage.consensus)}</td></tr>"
        f"<tr><td>分叉</td><td>{len(triage.branching)}</td></tr>"
        f"<tr><td>孤岛</td><td>{len(triage.outliers)}</td></tr>"
    )

    return f"""
    <div class="card" style="border:1px solid {space_color};">
      <h2 style="color:{space_color};">交互式 run 结果</h2>
      <p><b>Prompt:</b> <code>{prompt[:80]}</code></p>
      <p><b>解空间:</b> <span style="color:{space_color};font-weight:bold;">{m.solution_space}</span>
         <b>UCS:</b> <span style="color:{space_color if m.ucs >= 0.6 else '#e55'};">{m.ucs:.3f}</span>
         <b>N:</b> {m.n}</p>
      <div style="margin:12px 0;">
        <h3>度量</h3>
        {bars}
      </div>
      <div style="margin:12px 0;">
        <h3>三分摘要</h3>
        <table>{triage_html}</table>
      </div>
      <div style="margin:12px 0;">
        <h3>诊断结论</h3>
        <ul>{diag_html}</ul>
      </div>
    </div>
    """


def _cli_cmd_baseline(args) -> int:
    """pwp-qa baseline: 建立基线 / 漂移检测"""
    if args.action == "establish":
        gen = _make_cli_generator(args)
        if gen is None:
            return 1
        print("建立基线...")
        bl = establish_baseline(gen, n=args.n, level=args.level)
        print(f"\n基线已建立, 存储到 {BASELINE_PATH}")
        for i, r in enumerate(bl.get("results", []), 1):
            if "error" in r:
                print(f"  [{i}] ERROR: {r['error']}")
            else:
                print(f"  [{i}] UCS={r['ucs']:.3f} "
                      f"space={r['solution_space']} "
                      f"{r['prompt'][:40]}...")
    elif args.action == "check":
        gen = _make_cli_generator(args)
        if gen is None:
            return 1
        print("漂移检测...")
        result = detect_drift(gen, n=args.n, level=args.level,
                             threshold=args.threshold)
        print(drift_report_markdown(result))
    elif args.action == "show":
        bl = load_baseline()
        if not bl:
            print("未建立基线; 先跑 pwp-qa baseline establish")
            return 1
        ts = bl.get("established_at", 0)
        print(f"基线建立: {time.strftime('%Y-%m-%d %H:%M', time.localtime(ts))}")
        for i, r in enumerate(bl.get("results", []), 1):
            if "error" in r:
                print(f"  [{i}] ERROR: {r['error']}")
            else:
                print(f"  [{i}] UCS={r['ucs']:.3f} "
                      f"space={r['solution_space']} "
                      f"{r['prompt'][:40]}...")
    else:
        print("用法: pwp-qa baseline {establish|check|show}")
        return 1
    return 0


def _make_cli_generator(args):
    """从 CLI 参数构建 generator (复用 run/baseline 命令)"""
    backend = getattr(args, "backend", "mock")
    if backend == "mock":
        return _mock_generator_for_cli()
    api_key = getattr(args, "api_key", None) or os.environ.get("OPENAI_API_KEY")
    base_url = getattr(args, "base_url", None) or os.environ.get("OPENAI_BASE_URL")
    model = getattr(args, "model", None) or os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
    if not api_key and backend != "ollama":
        print(f"需要 --api-key 或 {backend.upper()}_API_KEY env")
        return None
    try:
        if backend == "openai":
            return make_openai_generator(model=model, api_key=api_key,
                                         base_url=base_url)
        elif backend == "anthropic":
            return make_anthropic_generator(model=model, api_key=api_key)
        elif backend == "ollama":
            return make_ollama_generator(model=model)
    except Exception as e:
        print(f"generator 初始化失败: {e}")
        return None
    return None


def _mock_generator_for_cli():
    """CLI 用的 mock generator (与 demo.py 一致)"""
    import random
    def gen(prompt: str, seed: int | None = None) -> str:
        rng = random.Random(seed)
        base = (
            "def add(a, b):\n    return a + b\n"
            "def sub(a, b):\n    return a - b\n"
        )
        mul = "def mul(a, b):\n    return a * b"
        div = "def div(a, b):\n    return a / b"
        code = base + mul + "\n"
        if rng.random() < 0.5:
            code += div + "\n"
        return code
    return gen


def _cli_cmd_compare(args) -> int:
    """pwp-qa compare: 多模型对比"""
    prompt = args.prompt
    n = args.n
    level = args.level

    generators = {}

    # mock 始终加入 (作为基线参照)
    generators["mock"] = _mock_generator_for_cli()

    # 按参数加入真实模型
    if args.openai_key or os.environ.get("OPENAI_API_KEY"):
        try:
            generators[args.openai_model or "gpt-4o-mini"] = make_openai_generator(
                model=args.openai_model or os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
                api_key=args.openai_key or os.environ.get("OPENAI_API_KEY"),
                base_url=args.openai_base or os.environ.get("OPENAI_BASE_URL"),
            )
        except Exception as e:
            print(f"OpenAI generator 初始化失败: {e}")
    if args.anthropic_key or os.environ.get("ANTHROPIC_API_KEY"):
        try:
            generators[args.anthropic_model or "claude-3-5-haiku-20241022"] = \
                make_anthropic_generator(
                    model=args.anthropic_model or "claude-3-5-haiku-20241022",
                    api_key=args.anthropic_key or os.environ.get("ANTHROPIC_API_KEY"),
                )
        except Exception as e:
            print(f"Anthropic generator 初始化失败: {e}")

    if len(generators) < 2:
        print("需要至少 2 个模型对比 (mock + 1 个真实模型)")
        print("用 --openai-key / --anthropic-key 或设 env")
        return 1

    print(f"对比 {len(generators)} 个模型: {', '.join(generators.keys())}")
    result = compare_models(prompt, generators, n=n, level=level)
    print(compare_models_markdown(result))
    return 0


def main(argv=None) -> int:
    """CLI 入口函数, 供 `pwp-qa` 命令调用."""
    import argparse
    import sys
    if argv is None:
        argv = sys.argv[1:]

    parser = argparse.ArgumentParser(
        prog="pwp-qa",
        description="PWP-QA: Parallel Worlds Paradigm for Code QA",
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )
    sub = parser.add_subparsers(dest="command", metavar="<command>")

    # demo (兼容旧入口)
    p_demo = sub.add_parser("demo", help="跑 mock demo (默认行为, 兼容旧入口)")
    p_demo.add_argument("--prompt", default="写一个简单的计算器", help="提示词")
    p_demo.add_argument("-n", type=int, default=5, help="宇宙数")
    p_demo.add_argument("--seed", type=int, default=42, help="种子 (控制 mock 行为)")
    p_demo.set_defaults(func=_cli_cmd_demo)

    # run
    p_run = sub.add_parser("run", help="跑一次多宇宙生成 + 三分 + 报告")
    p_run.add_argument(
        "--prompt",
        default="写一个简单的计算器: add/sub/mul/div",
        help="提示词",
    )
    p_run.add_argument(
        "--backend",
        choices=["mock", "openai", "anthropic", "ollama"],
        default="mock",
        help="LLM 后端 (默认 mock)",
    )
    p_run.add_argument("-n", type=int, default=5, help="宇宙数")
    p_run.add_argument("--seed", type=int, default=42, help="种子 (控制 mock)")
    p_run.add_argument(
        "--level", choices=["line", "ast"], default="ast", help="对齐层级"
    )
    p_run.add_argument(
        "--io-test", action="store_true", help="启用 L2.5 IO 等价测试"
    )
    p_run.add_argument(
        "--diagnose",
        action="store_true",
        help="追加 Prompt 质量诊断 (基于第 11 节映射表)",
    )
    p_run.add_argument(
        "--radar",
        action="store_true",
        help="追加 5 度量 ASCII 条形图",
    )
    p_run.add_argument(
        "--decide",
        action="store_true",
        help="追加 L8 最优决策 (第 16 节 D1-D5 决策树)",
    )
    p_run.add_argument(
        "--quality",
        action="store_true",
        help="追加 L8** Prompt 质量熵判据 Q(p) (第 18.1 节)",
    )
    p_run.add_argument(
        "--verify",
        action="store_true",
        help="追加 L8*** 形式化验证计划 (第 19.3 节 CT1-CT4)",
    )
    p_run.set_defaults(func=_cli_cmd_run)

    # converge
    p_conv = sub.add_parser("converge", help="L7 闭环自动收敛")
    p_conv.add_argument("--prompt", required=True, help="初始提示词")
    p_conv.add_argument(
        "--backend",
        choices=["mock", "openai", "anthropic", "ollama"],
        default="mock",
        help="LLM 后端 (mock 走 no_llm 路径, 1 轮即停)",
    )
    p_conv.add_argument(
        "--rewrite-backend",
        choices=["mock", "openai", "anthropic", "ollama"],
        default=None,
        help="prompt 改写用的 backend (默认同 --backend)",
    )
    p_conv.add_argument("-n", type=int, default=5, help="每轮宇宙数")
    p_conv.add_argument("--seed", type=int, default=42, help="种子")
    p_conv.add_argument(
        "--level", choices=["line", "ast"], default="ast", help="对齐层级"
    )
    p_conv.add_argument("--max-iter", type=int, default=5, help="最大迭代轮数")
    p_conv.add_argument(
        "--target-ucs", type=float, default=0.5, help="目标 UCS 阈值 (默认 0.5, 与经验校准阈值一致)"
    )
    p_conv.set_defaults(func=_cli_cmd_converge)

    # trend
    p_trend = sub.add_parser("trend", help="历史 UCS 趋势")
    p_trend.add_argument(
        "--limit", type=int, default=20, help="展示最近 N 次 run"
    )
    p_trend.set_defaults(func=_cli_cmd_trend)

    # baseline (阶梯 2: 连续基线)
    p_base = sub.add_parser("baseline", help="连续基线: 建立/检测/展示")
    p_base.add_argument(
        "action", choices=["establish", "check", "show"],
        help="establish=建立基线, check=漂移检测, show=查看基线",
    )
    p_base.add_argument("--backend", default="mock",
                        choices=["mock", "openai", "anthropic", "ollama"])
    p_base.add_argument("--model", default=None)
    p_base.add_argument("--api-key", default=None)
    p_base.add_argument("--base-url", default=None)
    p_base.add_argument("-n", type=int, default=5)
    p_base.add_argument("--level", choices=["line", "ast"], default="ast")
    p_base.add_argument("--threshold", type=float, default=0.15,
                        help="漂移阈值 (UCS 绝对差)")
    p_base.set_defaults(func=_cli_cmd_baseline)

    # web (阶梯 2: Web UI)
    p_web = sub.add_parser("web", help="启动 Web UI (http://localhost:PORT)")
    p_web.add_argument("--port", type=int, default=8765)
    p_web.set_defaults(func=_cli_cmd_web)

    # compare (阶梯 2: 多模型对比)
    p_cmp = sub.add_parser("compare", help="多模型对比: 同 prompt 跑不同模型")
    p_cmp.add_argument("--prompt", required=True, help="要对比的 prompt")
    p_cmp.add_argument("-n", type=int, default=5, help="每个模型跑几个宇宙")
    p_cmp.add_argument("--level", choices=["line", "ast"], default="ast")
    p_cmp.add_argument("--openai-key", default=None, help="OpenAI API key")
    p_cmp.add_argument("--openai-model", default=None, help="OpenAI 模型名")
    p_cmp.add_argument("--openai-base", default=None, help="OpenAI base_url")
    p_cmp.add_argument("--anthropic-key", default=None, help="Anthropic API key")
    p_cmp.add_argument("--anthropic-model", default=None, help="Anthropic 模型名")
    p_cmp.set_defaults(func=_cli_cmd_compare)

    # 兼容旧入口: python pwp_qa.py --prompt xxx -n 5
    # 第一个参数不是已知子命令时, 默认走 demo; 但顶层 -h/--help/--version 必须保留
    known_cmds = {"demo", "run", "converge", "trend", "baseline", "web", "compare"}
    top_level_flags = {"-h", "--help", "--version"}
    if not argv or (argv[0] not in known_cmds and not argv[0].startswith("-")):
        argv = ["demo"] + list(argv)
    elif argv[0].startswith("-") and argv[0] not in top_level_flags:
        argv = ["demo"] + list(argv)

    args = parser.parse_args(argv)
    if not hasattr(args, "func"):
        parser.print_help()
        return 0
    return args.func(args)


if __name__ == "__main__":
    import sys
    sys.exit(main())
